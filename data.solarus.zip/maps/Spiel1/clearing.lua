local map = ...
local game = map:get_game()

function map:on_started()
  
  if game:get_value("mastersword_received") then
    mastersword:set_enabled(false)
  end
end


function mastersword:on_interaction()

  if game:has_item("amulet_of_courage") then
    hero:freeze()
    sol.audio.play_music("excalibur")
    x,y,layer = hero:get_position()
    amulet = map:create_pickable({name = "amulet_of_courage", layer = layer, x = x, y = y+24, treasure_name = "amulet_of_courage"})
     
    for i=1,4 do
      sol.timer.start(2500*i, function()
        xm, ym, layerm = mastersword:get_position()
        mastersword:set_position(xm, ym-1, layerm)
      end)
    end

    sol.timer.start(10000, function()
      
      mastersword:set_enabled(false)
      amulet:remove()
      hero:start_treasure("sword", 2, "mastersword_received", function()

        hero:start_victory(function()
    
          hero:unfreeze()
          sol.audio.play_music("lost_woods")
        end)
      end)
    end)
  end
end