local map = ...
local game = map:get_game()

local door_castle_is_opening



function map:on_started()

  map:set_entities_enabled("gravestone_1_stairs", false)
  door_castle_is_opening = false

  if game:get_value("castle_fence_open_state") then
    map:set_entities_enabled("castle_fence", false)
    Ganon:set_enabled(false)
  end

  if game:get_value("castle_door_open") then
    door_castle:set_enabled(false)
  end
end


-- Öffnen des Zaunes zum Schloss
function castle_fence_open:on_interaction()

  if game:get_item("sword"):get_variant() > 1 then
    hero:start_victory(function()
      
      hero:freeze()
      for i=1, 5 do
        sol.timer.start(500 * i, function()
          
          if i<5 then

            map:set_entities_enabled("castle_fence" .. i, false)
            sol.audio.play_sound("door_open")
          else
            Ganon:set_enabled(false)
            sol.audio.play_sound("warp")
            sol.timer.start(2000, function()

              hero:unfreeze()
              sol.audio.play_sound("secret")
              castle_fence_open:set_enabled(false)
              game:set_value("castle_fence_open_state", true)
            end)
          end
        end)
      end
    end)
  end
end



-- Öffnen der Tür zum Schloss
for i=1, 2 do
  local entity_torch = map:get_entity("torch_" .. i)
  function entity_torch:on_collision_fire()

    if light_torch("torch_", i, 5000) and door_castle:is_enabled() and not door_castle_is_opening then
      door_castle_is_opening = true
      sol.timer.stop_all(map)
      hero:freeze()
      local x, y, layer = door_castle:get_position()
      
      for i = 0, 6 do
        sol.timer.start(300 * i, function()
          if i < 6 then
            door_castle:set_position(x, y - 4*(i+1), layer)
            sol.audio.play_sound("door_open")
          else
            sol.audio.play_sound("secret")
            door_castle:set_enabled(false)
            game:set_value("castle_door_open", true)
            hero:unfreeze()
          end
        end)
      end
    end
  end
end



-- Verschieben der Grabsteine
for i = 1, map:get_entities_count("sensor_gravestone") do
  local sensor = map:get_entity("sensor_gravestone_" .. i)
  function sensor:on_activated()

    if hero:get_state() == "pushing" then
      move_gravestone("gravestone_" .. i)
    end
  end
end


function move_gravestone(name)
  
  local gravestone = map:get_entity(name)
  local x, y, layer = gravestone:get_position()
  hero:freeze()
  sol.audio.play_sound("hero_pushes")

  hero:set_walking_speed(40)
  hero:walk("66")

  sol.timer.start(400, function()

    hero:set_walking_speed(88)
    hero:set_direction(1)
    hero:freeze()
  end)

  for i=0, 8 do
    sol.timer.start(i*100, function()

      gravestone:set_position(x, y-i-1, layer)
      if i == 8 then 
        hero:unfreeze() 
        if map:has_entity(name .. "_stairs") then
          map:set_entities_enabled(name .. "_stairs", true)
          sol.audio.play_sound("secret")
        else
          map:create_pickable({name = "grave_pickable_" .. name, layer = layer, x = x, y = y+8, treasure_name = "random_pickable"})
        end
      end
    end)
  end
end



-- entzündet die Fackel mit dem Namen 'torch_prefix' .. 'torch_number' für eine Zeit 'time' und überprüft, ob alle Fackeln mit dem Präfix 'torch_prefix' entzündet sind. Wenn dies der Fall ist, liefert die Funktion 'true' zurück, ansonsten 'false'
function light_torch(torch_prefix, torch_number, time)

  local sprite = map:get_entity(torch_prefix .. torch_number):get_sprite()

  if sprite:get_animation() == "unlit" then
    sprite:set_animation("lit")
    if time > 0 then
      sol.timer.start(time, function()
        sprite:set_animation("unlit")
      end)
    end
  end
 
  local all_lit = true
  
  for entities in map:get_entities(torch_prefix) do
    local sprites = entities:get_sprite()
    all_lit = all_lit and sprites:get_animation() == "lit"
  end

  return all_lit
end



function cave_bomb_hole:on_opened()

  sol.audio.play_sound("secret")
end



