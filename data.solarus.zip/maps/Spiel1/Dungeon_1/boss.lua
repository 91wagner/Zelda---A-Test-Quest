local map = ...
local game = map:get_game()
  local hero = map:get_entity("hero")


function map:on_started()

  if not game:get_value("dungeon_1_finished") then
    teleporter:set_enabled(false)
  else
    sol.audio.play_music("light_world_dungeon")
  end
end


function map:on_opening_transition_finished(destination)
  if not game:get_value("dungeon_1_boss_defeated") then
    sol.audio.play_music("boss")
  elseif not game:get_value("dungeon_1_finished") then
    map:open_doors("door_boss")
  end
end


if not game:get_value("dungeon_1_boss_defeated") then
  function boss:on_dead()

    map:open_doors("door_boss")
    sol.audio.stop_music()
  end
end


function sensor_boss:on_activated()
  sol.audio.play_music("dungeon_finished")
  hero:walk("222222222222222222222222222222222222222222")
  sol.timer.start(3700, function()
    game:start_dialog("sahasrahla.captured.1", function()
      sol.audio.stop_music()
      sol.audio.play_music("victory")
      hero:freeze()
      sol.timer.start(8500, function()
        hero:unfreeze()
        hero:start_victory(function()
          hero:freeze()
          sol.timer.start(500, function()
            sol.audio.play_sound("world_warp")
            hero:teleport("Spiel1/overworld_1_3", "overworld1_3_entrance_dungeon")
            hero:unfreeze()
            game:set_value("dungeon_1_finished", true)
          end)
        end)
      end)        
    end)
  end)
end