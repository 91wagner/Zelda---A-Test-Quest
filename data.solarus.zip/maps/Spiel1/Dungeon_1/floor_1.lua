local map = ...
local game = map:get_game()


function map:on_started()
  room_1_bridge:set_enabled(false)

  if game:get_value("difficulty") == "easy" then
    map:set_entities_enabled("weg", false)
    room_21_enemy_5:set_enabled(false)
    room_5_enemy_2:set_enabled(false)
  end

  if room_2_chest:is_open() then
    switch_room_2_chest:set_activated(true)
  else
    room_2_chest:set_enabled(false)
  end

  map:set_doors_open("door_inside_boss_room")

  map:set_doors_open("door_room_5")
  if not room_5_chest_big_key:is_open() then
    room_5_chest_big_key:set_enabled(false)
  end

  game:set_value("dungeon_1_room_15_stairs_appeared", false)
  if not dungeon_1_room_15_chest:is_open() then
    dungeon_1_room_15_chest:set_enabled(false)
  else
    dungeon_1_room_15_switch:set_activated(true)
  end
  for i = 1, 7 do
    map:get_entity("dungeon_1_room_15_stairs_" .. i):set_enabled(false)
  end


  if game:get_value("dungeon_1_room_18_stairs_enabled") then
  
    for i = 1, 7 do
      map:get_entity("stairs_room_18_" .. i):set_enabled(true)
    end
    dungeon_1_room_18_barrier:set_enabled(false)
    room_18_switch:set_activated(true)
  else
    stairs_room_18_7:set_enabled(false)
  end
end

-------------------------------------------
-- Raum 1


function room_1_switch:on_activated()
  room_1_bridge:set_enabled(true)
  sol.audio.play_sound("secret")
end

-------------------------------------------
-- Raum 2

function room_2_switch:on_activated()
  map:open_doors("door_1_2")
  sol.audio.play_sound("secret")
end 

function switch_room_2_chest:on_activated()
  room_2_chest:set_enabled(true)
  sol.audio.play_sound("chest_appears")
end

-------------------------------------------
-- Raum Boss


function boss_room_entrance:on_activated()
  map:close_doors("door_inside_boss_room")
end


-------------------------------------------
-- Raum 5
function room_5_switch:on_activated()
  map:close_doors("door_room_5")
end

local room_5_enemy_count = 4

if game:get_value("difficulty") == "easy" then
  room_5_enemy_count = 3
end

for room_5_enemies in map:get_entities("room_5_enemy_") do 
  function room_5_enemies:on_dead()
    room_5_enemy_count = room_5_enemy_count - 1
    if room_5_enemy_count <= 0 then
      sol.audio.play_sound("secret")
      map:open_doors("door_room_5")
      if not room_5_chest_big_key:is_open() then
        room_5_chest_big_key:set_enabled(true)
        sol.audio.play_sound("chest_appears")
      end
    end
  end
end



function door_room_9_14:on_opened()
  sol.audio.play_sound("secret")
end

------------------------------------------
-- Raum 15
function dungeon_1_room_15_switch:on_activated() 

  local camera_x, camera_y = dungeon_1_room_15_chest:get_position()
  map:move_camera(camera_x, camera_y, 104, function()

    dungeon_1_room_15_chest:set_enabled(true)
    sol.audio.play_sound("chest_appears")
  end)
end

function dungeon_1_room_15_chest:on_empty()
  hero:start_treasure("rupee", 3)
end

------------------------------------------
-- Raum 14 fuer Raum 15
function dungeon_1_room_14_sensor:on_activated() 
  if dungeon_1_room_15_chest:is_open() and not game:get_value("dungeon_1_room_15_stairs_appeared") then
    for i = 1, 7 do
      map:get_entity("dungeon_1_room_15_stairs_" .. i):set_enabled(true)
    end
    dungeon_1_room_15_jumper:set_enabled(false)
    dungeon_1_room_15_sign:set_enabled(false)
    sol.audio.play_sound("secret")
    game:set_value("dungeon_1_room_15_stairs_appeared", true)
  end
end


-----------------------------------------
-- Raum 18
function room_18_switch:on_activated()
  for i = 1, 7 do
    map:get_entity("stairs_room_18_" .. i):set_enabled(true)
  end
  dungeon_1_room_18_barrier:set_enabled(false)
  game:set_value("dungeon_1_room_18_stairs_enabled", true)
  sol.audio.play_sound("secret")
end


-----------------------------------------------
-- Raum 21
local room_21_enemy_count = 5

if game:get_value("difficulty") == "easy" then
  room_21_enemy_count = 4
end

for room_21_enemies in map:get_entities("room_21_enemy_") do 
  function room_21_enemies:on_dead()
    room_21_enemy_count = room_21_enemy_count - 1
    if room_21_enemy_count <= 0 then

      local camera_x, camera_y = room_21_barrier:get_position()
      map:move_camera(camera_x, camera_y, 104, function()

        sol.audio.play_sound("secret")
        room_21_barrier:set_enabled(false)
      end)
    end
  end
end

function room_21_switch:on_activated()
  sol.audio.play_sound("secret")
  for hole in map:get_entities("room_21_hole_") do
    hole:set_enabled(false)
  end
  room_21_star:set_enabled(false)
end


-----------------------------------------------------------
-- Raum 25
function room_25_switch:on_activated()
  
  local camera_x, camera_y = room_25_barrier:get_position()
  map:move_camera(camera_x, camera_y, 104, function()

    room_25_barrier:set_enabled(false)
    sol.audio.play_sound("secret")
  end)
end

function room_25_enemy:on_dead()

  local camera_x, camera_y = room_25_barrier_2:get_position()
  map:move_camera(camera_x, camera_y, 104, function()

    room_25_barrier_2:set_enabled(false)
    sol.audio.play_sound("secret")
  end)
end

function room_25_weak_wall:on_opened()
  sol.audio.play_sound("secret")
end
