local map = ...
local game = map:get_game()



function map:on_started()

  local price_bomb_bag = 50
  local price_shield_2 = 150
  local price_rupee_bag_1 = 30
  local price_rupee_bag_2 = 200
  local price_bomb_bag_2 = 300
  local price_heart_container = 500

  if game:get_value("difficulty") == "easy" then

    map:set_entities_enabled("weg", false)
    price_bomb_bag = 30
    price_shield_2 = 100
    price_rupee_bag_1 = 30
    price_rupee_bag_2 = 150
    price_bomb_bag_2 = 250
    price_heart_container = 350
  end

  if game:get_value("dungeon_2_finished") then
    shop_man_2:set_enabled(false)

    map:create_shop_treasure({
      name = "shop_item_bomb_bag_1",
      layer = 1,
      x = 240,
      y = 64,
      price = price_bomb_bag,
      dialog = "_shop.item.bomb_bag.1",
      treasure_name = "bomb_bag", 
      treasure_variant = 1,
      treasure_savegame_variable = "shop_bomb_bag_1_bought"
    })
  else
    shop_man:set_enabled(false)
  end



  if chest_fire_stone:is_open() then
    switch_chest:set_activated(true)
  else
    chest_fire_stone:set_enabled(false)
  end


  if game:has_item("shield") then
    
    map:create_shop_treasure({
      name = "shop_item_shield_2",
      layer = 1,
      x = 192,
      y = 112,
      price = price_shield_2,
      dialog = "_shop.item.shield.2",
      treasure_name = "shield",
      treasure_variant = 2,
      treasure_savegame_variable = "shop_shield_2_bought"
    })
  end
  


  map:create_shop_treasure({
    name = "shop_item_rupee_bag_1",
    layer = 1,
    x = 240,
    y = 112,
    price = price_rupee_bag_1,
    dialog = "_shop.item.rupee_bag.1",
    treasure_name = "rupee_bag",
    treasure_variant = 1,
    treasure_savegame_variable = "shop_rupee_bag_1_bought"
  })
  


  if game:has_item("rupee_bag") and game:get_value("dungeon_2_finished") then

    map:create_shop_treasure({
      name = "shop_item_rupee_bag_2",
      layer = 1,
      x = 240,
      y = 112,
      price = price_rupee_bag_2,
      dialog = "_shop.item.rupee_bag.2",
      treasure_name = "rupee_bag",
      treasure_variant = 2,
      treasure_savegame_variable = "shop_rupee_bag_2_bought"
    })
  end

  if game:get_value("shop_bomb_bag_1_bought") and game:get_value("shop_rupee_bag_2_bought") and game:get_value("dungeon_1_finished") then

    map:create_shop_treasure({
      name = "shop_item_bomb_bag_2",
      layer = 1,
      x = 240,
      y = 112,
      price = price_bomb_bag_2,
      dialog = "_shop.item.bomb_bag.2",
      treasure_name = "bomb_bag", 
      treasure_variant = 2,
      treasure_savegame_variable = "shop_bomb_bag_2_bought"
    })

  end


  if game:get_value("shop_bomb_bag_2_bought") and game:get_value("shop_shield_2_bought") and game:get_value("dungeon_3_boss") then

    map:create_shop_treasure({
      name = "shop_item_heart_container",
      layer = 1,
      x = 240,
      y = 112,
      price = price_heart_container,
      dialog = "_shop.item.heart_container.1",
      treasure_name = "heart_container", 
      treasure_variant = 1,
      treasure_savegame_variable = "shop_heart_container_bought"
    })

  end

  if game:get_value("shop_1_you_made_it") then
    transporter_you_made_it:set_enabled(true)
    switch_you_made_it:set_activated(true)
  else
    transporter_you_made_it:set_enabled(false)
  end
end



function shop_thief:on_interaction()
  if game:get_value("shop_thief_got_item") then
    game:start_dialog("_shop.thief.later")
    return
  end
    
  if not game:has_item("fire_stone") then
    game:start_dialog("_shop.thief.want")
  else
    game:start_dialog("_shop.thief.have", function(answer)
      if answer == 2 then
        game:start_dialog("_shop.thief.yes", function()
          local fire_stone = game:get_item("fire_stone")
          fire_stone:set_variant(0)
          hero:start_treasure("empty_bottle", 1)
          game:set_value("shop_thief_got_item", true)
        end)
      else
        game:start_dialog("_shop.thief.no")
      end
    end)
  end
end




function switch_vanishing_block_1:on_activated()
  vanishing_block_1:set_enabled(false)

  sol.timer.start(7000, function()
    vanishing_block_1:set_enabled(true)
    switch_vanishing_block_1:set_activated(false)
  end):set_with_sound()
end




function switch_chest:on_activated()
  sol.audio.play_sound("chest_appears")
  chest_fire_stone:set_enabled(true)
end

function switch_you_made_it:on_activated()
  transporter_you_made_it:set_enabled(true)
  game:set_value("shop_1_you_made_it", true)
end

