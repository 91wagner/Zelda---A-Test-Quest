local map = ...
local game = map:get_game()


function map:on_started()

  if game:get_value("blacksmith_door") then
    switch_door:set_activated(true)
  end
end


function switch_door:on_activated()

  map:open_doors("door")
  sol.audio.play_sound("secret")
end


function smith:on_interaction()

  if game:has_item("sword") then
    local sword_variant = game:get_item("sword"):get_variant()

    if sword_variant == 1 then
      game:start_dialog("smith.1")
    elseif sword_variant == 2 then
      game:start_dialog("smith.2", function(answer)
        if answer == 2 then
          if game:get_money() < 200 then
            game:start_dialog("_shop.not_enough_money")
          else
            game:start_dialog("smith.2.yes", function()
              game:remove_money(200)
              hero:start_treasure("sword", 3)
            end)
          end
        elseif answer == 3 then
          game:start_dialog("smith.2.no")
        end
      end)
    elseif sword_variant == 3 then
      game:start_dialog("smith.3", function(answer)
        if answer == 3 then
          if game:get_value("possession_gold_bar") then
            if game:get_money() > 499 then
              game:start_dialog("smith.3.yes", function()
                game:remove_money(500)
                game:set_value("possession_gold_bar", false)
                hero:start_treasure("sword", 4)
              end)
            else
              game:start_dialog("_shop.not_enough_money")
            end
          else
            game:start_dialog("smith.gold_bar_missing")
          end
        elseif answer == 4 then
          game:start_dialog("smith.3.no")
        end
      end)
    elseif sword_variant == 4 then
      game:start_dialog("smith.4")
    end
  end
end