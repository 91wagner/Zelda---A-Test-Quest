local map = ...
local game = map:get_game()
function map:on_started()
  sahasrahla:set_enabled(false)
  if game:get_value("dungeon_1_finished") then
    sahasrahla:set_enabled(true)
  end
end

function wife_of_sahasrahla:on_interaction()
  if game:get_value("dungeon_1_finished") then
    game:start_dialog("wife_of_sahasrahla.thanks")
  elseif game:get_value("dungeon_2_finished") then
    game:start_dialog("wife_of_sahasrahla.shop_man")
  else
    game:start_dialog("wife_of_sahasrahla.help")
  end
end

function sahasrahla:on_interaction()

  if game:get_item("sword"):get_variant() > 2 and game:get_ability("tunic") > 1 and game:get_value("castle_fence_open_state") then
    game:start_dialog("sahasrahla.free.no_advices")
  elseif game:get_item("sword"):get_variant() > 1 then
    game:start_dialog("sahasrahla.free.ganon")
  elseif game:has_item("amulet_of_courage") then
    game:start_dialog("sahasrahla.free.get_sword")
  elseif game:has_item("pegasus_shoes") then
    game:start_dialog("sahasrahla.free.1")
  else
    game:start_dialog("sahasrahla.free.2", function() 
      hero:start_treasure("pegasus_shoes")
    end)
  end
end