local map = ...
local game = map:get_game()
local movement = sol.movement.create("random_path")

function map:on_started()

  if game:has_item("sword") then
    Zelda:set_enabled(false)
  else
    movement:set_speed(16)
    movement:start(Zelda)
    overworld_1_1_sign:set_enabled(false)
    loch:set_enabled(false)
  end

  if chest_1:is_open() then
    chest_1:set_enabled(false)
  end
  if chest_2:is_open() then
    chest_2:set_enabled(false)
  end
end


function map:on_opening_transition_finished()

  if game:get_value("difficulty") == nil then
    game:start_dialog("set_difficulty", function(answer)

      if answer == 2 then
        game:set_value("difficulty", "easy")
        game:set_max_life(20)
        game:set_life(20)
        game:set_value("nb_hearts_per_row", 7)
      else
        game:set_value("difficulty", "normal")
      end
      game:start()
    end)
  end  
end


function overworld_1_1_sign:on_interaction()
  
  if game:get_value("ganon_defeated") then
    game:start_dialog("overworld_1_1.sign.3")
  else
    game:start_dialog("overworld_1_1.sign.1")
  end
end


function Zelda:on_interaction()
  movement:stop(Zelda)

  if game:has_item("shield") then
    game:start_dialog("_zelda.shield")
    movement:start(Zelda)
    return
  end

  game:start_dialog("_zelda.beginning")

  movement:start(Zelda)
end