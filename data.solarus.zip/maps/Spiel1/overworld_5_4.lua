local map = ...


function cave_bomb_hole:on_opened()

  sol.audio.play_sound("secret")
end

