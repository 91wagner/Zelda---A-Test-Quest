local map = ...


function bush:on_cut()

  sol.audio.play_sound("secret")
end


for bushes in map:get_entities("bushes") do

  function bushes:on_cut()

    sol.audio.play_sound("secret")
    map:set_entities_enabled("bushes", false)
  end
end