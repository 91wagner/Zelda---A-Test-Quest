local map = ...

function overworld_1_3_weak_wall:on_opened()
  sol.audio.play_sound("secret")
end