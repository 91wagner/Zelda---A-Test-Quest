local map = ...
local game = map:get_game()


function map:on_started()

  if game:get_value("Baumstamm_verbrannt") then
    Baumstamm:set_enabled(false)
    Baumstamm_npc:set_enabled(false)
  end

  if game:get_value("Baumstamm_2_verbrannt") then
    Baumstamm_2:set_enabled(false)
    map:set_entities_enabled("Baumstamm_npc_", false)
    map:set_entities_enabled("Treppe", true)
  else
    map:set_entities_enabled("Treppe", false)
  end

  if game:get_value("difficulty") == "easy" then
    loch_weg_easy:set_enabled(false)
  end
  
end


function Baumstamm_npc:on_collision_fire()

  hero:freeze()
  x, y, layer = Baumstamm_npc:get_position()
  Baumstamm_npc:set_enabled(false)
  for i=1 , 5 do
    
    sol.timer.start(400*i, function()
      if i==5 then
        sol.audio.play_sound("secret")
        Baumstamm:set_enabled(false)
        game:set_value("Baumstamm_verbrannt", true)
        hero:unfreeze()
        sol.timer.stop_all(map)
      else
        burning_fire({x = x-4, y = y - (i-1)*8, layer = layer})
        burning_fire({x = x+4, y = y - (i-1)*8, layer = layer})
        burning_fire({x = x-8, y = y - (i-1)*8, layer = layer})
        burning_fire({x = x+8, y = y - (i-1)*8, layer = layer})
        sol.audio.play_sound("lamp")
      end
    end)
  end
end


for stumps in map:get_entities("Baumstamm_npc_") do
function stumps:on_collision_fire()

  hero:freeze()
  x = 872
  y = 653
  layer = 0

  map:set_entities_enabled("Baumstamm_npc_", false)
  for i=1 , 5 do
    
    sol.timer.start(400*i, function()
      if i==5 then
        sol.audio.play_sound("secret")
        map:set_entities_enabled("Treppe", true)
        Baumstamm_2:set_enabled(false)
        game:set_value("Baumstamm_2_verbrannt", true)
        hero:unfreeze()
        sol.timer.stop_all(map)
      else
        burning_fire({x = x-4, y = y - (i-1)*8, layer = layer})
        burning_fire({x = x+4, y = y - (i-1)*8, layer = layer})
        burning_fire({x = x-8, y = y - (i-1)*8, layer = layer})
        burning_fire({x = x+8, y = y - (i-1)*8, layer = layer})
        sol.audio.play_sound("lamp")
      end
    end)
  end
end
end



function burning_fire(position)

  sol.timer.start(200, function()

    map:create_fire(position)
    burning_fire(position)
  end)
end