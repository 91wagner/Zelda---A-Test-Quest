local map = ...
local game = map:get_game()
local number_switches


local function open_turtle_door()

  local door_x, door_y, door_layer = dungeon_exit_door:get_position()

  for i = 0, 31 do
    sol.timer.start(i*200, function()

      dungeon_exit_door:set_position(door_x, door_y - i, door_layer)
      if i%3 == 0 then
        sol.audio.play_sound("hero_pushes")
      end
      if i == 31 then
        sol.audio.play_sound("secret")
      end
    end)
  end
end


function map:on_started()

  map:set_entities_enabled("gravestone_1_stairs", false)

  if game:get_value("dungeon_3_open") then
    map:set_entities_enabled("switch_dungeon_entrance", false)
    door_blocker:set_enabled(false)
  else
    number_switches = 0
  end
end


function map:on_opening_transition_finished()
  
  local hero_x, hero_y = hero:get_position()
  if hero_x > 590 and hero_x < 630 and hero_y > 570 and hero_y < 610 then    
    hero:freeze()
    sol.timer.start(200, function()

      open_turtle_door()
    end)

    sol.timer.start(7000, function()
      hero:unfreeze()
    end)
  end


end


for switches in map:get_entities("switch_dungeon_entrance") do

  function switches:on_activated()

    number_switches = number_switches + 1
    if number_switches == 6 then
      door_blocker:set_enabled(false)
      game:set_value("dungeon_3_open", true)
      sol.audio.play_sound("secret")
      sol.timer.stop_all(map)

    elseif number_switches == 1 then
      sol.timer.start(25000, function()

        number_switches = 0
        if game:get_value("dungeon_3_open") then
          map:set_entities_enabled("switch_dungeon_entrance", false)
        else
          for switch in map:get_entities("switch_dungeon_entrance") do
            switch:set_activated(false)
          end
        end
      end):set_with_sound(true)

    end
  end
end


function desert_weak_block:on_opened()

  sol.audio.play_sound("secret")
end

function bomb_door_desert:on_opened()

  sol.audio.play_sound("secret")
end

function bomb_door_desert_fairy:on_opened()

  sol.audio.play_soung("secret")
end

-- Verschieben der Grabsteine
for i = 1, map:get_entities_count("sensor_gravestone") do
  local sensor = map:get_entity("sensor_gravestone_" .. i)
  function sensor:on_activated()

    if hero:get_state() == "pushing" then
      move_gravestone("gravestone_" .. i)
    end
  end
end


function move_gravestone(name)
  
  local gravestone = map:get_entity(name)
  local x, y, layer = gravestone:get_position()
  hero:freeze()
  sol.audio.play_sound("hero_pushes")

  hero:set_walking_speed(40)
  hero:walk("66")

  sol.timer.start(400, function()

    hero:set_walking_speed(88)
    hero:set_direction(1)
    hero:freeze()
  end)

  for i=0, 8 do
    sol.timer.start(i*100, function()

      gravestone:set_position(x, y-i-1, layer)
      if i == 8 then 
        hero:unfreeze() 
        if map:has_entity(name .. "_stairs") then
          map:set_entities_enabled(name .. "_stairs", true)
          sol.audio.play_sound("secret")
        else
          map:create_pickable({name = "grave_pickable_" .. name, layer = layer, x = x, y = y+8, treasure_name = "random_pickable"})
        end
      end
    end)
  end
end