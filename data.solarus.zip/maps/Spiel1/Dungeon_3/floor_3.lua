local map = ...
local game = map:get_game()



local function move_wall()
  local x, y, layer = moving_wall_1:get_position()
  local extra_x = {0, -8, -32, -32, -32, -36, -36, -36}
  local extra_y = {0, 16, 40, 16, 200, 40, 48, 192}

  hero:freeze()
  for i = 0, 160 do

    sol.timer.start(80*i, function()

      for j = 1, 8 do
        map:get_entity("moving_wall_" .. j):set_position(x + 2*i + extra_x[j], y + extra_y[j], layer)
      end
      if i == 160 then
        sol.audio.play_sound("secret")
        map:set_entities_enabled("moving_wall", false)
        game:set_value("dungeon_3_wall_moved", true)
        hero:unfreeze()
      end
      if i % 5 == 1 then
        sol.audio.play_sound("hero_pushes")
      end
    end)

  end
end



function map:on_started()

  if game:get_value("dungeon_3_boss") then
    map:open_doors("door_boss", true)
  end

  if not game:get_value("dungeon_3_boss_heart_container") and game:get_value("dungeon_3_boss") then
    map:create_pickable({
      name = "heart_container",
      layer = 1,
      x = 800,
      y = 221,
      treasure_name = "heart_container",
      treasure_savegame_variable = "dungeon_3_boss_heart_container",
    })
  end

  map:set_doors_open("false_door", true)
  
  if not game:get_value("dungeon_3_boss") then
    boss:set_enabled(false)
  end

  if game:get_value("dungeon_3_wall_moved") then
    map:set_entities_enabled("moving_wall", false)

    local x,y, layer = moving_wall_1:get_position()
    moving_wall_1:set_position(x + 320, y, layer)
    arrow_target_moving_wall:set_enabled(false)
  end
end


if map:has_entity("boss") then
  function boss:on_dead()

    map:open_doors("door_boss", true)
    sol.audio.play_sound("secret")
    sol.audio.stop_music()

    map:create_pickable({
      name = "heart_container",
      layer = 1,
      x = 800,
      y = 221,
      treasure_name = "heart_container",
      treasure_savegame_variable = "dungeon_3_boss_heart_container",
    })
  end
end


function map:on_opening_transition_finished()

  local hero_x, hero_y = hero:get_position()
  if hero_x > 780 and hero_x < 820 and hero_y > 400 and hero_y < 460 and not game:get_value("dungeon_3_boss") then
    sol.audio.stop_music()
    sol.audio.play_music("boss")
    
    boss:set_enabled(true)
  end
end


function sensor_false_door:on_activated()

  map:close_doors("false_door")
end


function sensor_false_door_2:on_activated()

  map:close_doors("false_door")
end


function arrow_target_moving_wall:on_activated()

  move_wall()
end 


function weak_wall:on_opened()

  sol.audio.play_sound("secret")
end
