local map = ...
local game = map:get_game()


local arrow_target_hit = false



function map:on_started()

  if chest_rupees:is_open() then
    arrow_target_rupee_chest:set_enabled(false)
  else
    chest_rupees:set_enabled(false)
  end

  map:set_entities_enabled("bridge", false)
  if game:get_value("dungeon_3_floor_1_last_switch_activated") then
    last_bridge:set_enabled(true)
    last_switch:set_activated(true)
  end

  if not chest_labyrinth:is_open() then
    chest_labyrinth:set_enabled(false)
  else
    switch_labyrinth:set_activated()
  end

  if not chest_top_middle:is_open() then
    chest_top_middle:set_enabled(false)
  else
    pike_chest:set_enabled(false)
  end
    
  map:set_doors_open("door_top_middle")
  map:set_entities_enabled("bumper", false)
end


function arrow_target_left:on_activated()

  if arrow_target_hit then
    map:open_doors("door_with_arrows")
    sol.audio.play_sound("secret")
    switch_door:set_activated()
  else
    arrow_target_hit = true
  end  
end


function arrow_target_right:on_activated()

  if arrow_target_hit then
    map:open_doors("door_with_arrows")
    sol.audio.play_sound("secret")
    switch_door:set_activated()
  else
    arrow_target_hit = true
  end  
end  


function arrow_target_rupee_chest:on_activated()

  if not chest_rupees:is_open() then
    sol.audio.play_sound("secret")
    chest_rupees:set_enabled(true)
  end
end


function switch_door:on_activated()

  if not door_with_arrows:is_open() then
    sol.audio.play_sound("secret")
    map:open_doors("door_with_arrows")
    map:set_entities_enabled("arrow_target", false)
  end
end

--Brücken und zugehörige Schalter
local function deactivate_switches()

  sol.timer.start(2000, function()

    switch1:set_activated(false)
    switch2:set_activated(false)
    switch3:set_activated(false)
  end)
  map:set_entities_enabled("bridge", false)
end


function switch1:on_activated()

  deactivate_switches()
  bridge1_2:set_enabled()
  bridge3_1:set_enabled()
  bridge3_3:set_enabled()
end


function switch2:on_activated()

  deactivate_switches()
  bridge2_3:set_enabled()
  bridge1_3:set_enabled()
  bridge2_2:set_enabled()
  bridge2_1:set_enabled()
end


function switch3:on_activated()

  deactivate_switches()
  bridge1_2:set_enabled()
  bridge1_3:set_enabled()
  bridge2_2:set_enabled()
  bridge2_3:set_enabled()
  bridge3_2:set_enabled()
  bridge3_3:set_enabled()
end


function last_switch:on_activated()

  if not game:get_value("dungeon_3_floor_1_last_switch_activated") then
    map:move_camera(232, 112, 120, function()
  
      sol.audio.play_sound("secret")
      last_bridge:set_enabled()
      game:set_value("dungeon_3_floor_1_last_switch_activated", true)
    end)
  end
end 


function sensor_way_back:on_activated()
  
  bridge2_1:set_enabled()
  bridge3_1:set_enabled()
end

-- Schluessel Raum
function sensor_top_middle:on_activated()
  
  if map:has_entities("bumper") then
    map:close_doors("door_top_middle")
    map:set_entities_enabled("bumper")
  end
end


for enemies in map:get_entities("bumper") do
  function enemies:on_dead()

    if not map:has_entities("bumper") then
      chest_top_middle:set_enabled()
      map:open_doors("door_top_middle")
      pike_chest:set_enabled(false)
      sol.audio.play_sound("secret")
    end
  end
end

-- Labyrinth
function switch_labyrinth:on_activated()

  chest_labyrinth:set_enabled()

  sol.timer.start(10000, function()

    if not chest_labyrinth:is_open() then
      chest_labyrinth:set_enabled(false)
      switch_labyrinth:set_activated(false)
    end
  end):set_with_sound(true)
end


function switch_labyrinth_wall:on_activated()

  map:move_camera(800, 500, 120, function()
    map:set_entities_enabled("labyrinth_wall", false)
    sol.audio.play_sound("secret")
  end)
end
