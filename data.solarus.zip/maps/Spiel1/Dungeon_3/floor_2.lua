local map = ...
local game = map:get_game()

local arrow_target_activated




function map:on_started()

  if game:get_value("dungeon_3_floor_2_solid_switch") or chest_big_key:is_open() then
    chest_big_key:set_enabled(true)
    solid_switch:set_activated(true)
  else
    chest_big_key:set_enabled(false)
  end

  if big_chest:is_open() then
    map:set_entities_enabled("big_chest", true)
    map:set_entities_enabled("arrow_target", false)
  else
    map:set_entities_enabled("big_chest", false)
  end

  arrow_target_activated = false

  if game:get_value("dungeon_3_floor_2_stairs1") then
    map:set_entities_enabled("stairs1", true)
    switch_stairs1:set_activated(true)
  else
    stairs1:set_enabled(false)
  end

  map:set_doors_open("door_miniboss")
  if game:get_value("dungeon_3_mini_boss") then
    sensor_mini_boss:set_enabled(false)
  end

  if map:has_entity("miniboss") then
    miniboss:set_enabled(false)
  end
end


function sensor_mini_boss:on_activated()
  miniboss:set_enabled(true)
  map:close_doors("door_miniboss")
  sol.audio.play_music("boss")
  sensor_mini_boss:set_enabled(false)
end


if map:has_entity("miniboss") then
  function miniboss:on_dead()

    sol.audio.play_music("southern_shrine")
    sol.audio.play_sound("secret")
    map:open_doors("door_miniboss")
  end
end


function solid_switch:on_activated()

  if not game:get_value("dungeon_3_floor_2_solid_switch") then
    game:set_value("dungeon_3_floor_2_solid_switch", true)
    chest_big_key:set_enabled(true)
    sol.audio.play_sound("secret")
  end
end


function arrow_target_left:on_activated()

  if arrow_target_activated then
    map:set_entities_enabled("big_chest", true)
    sol.audio.play_sound("secret")
  else
    arrow_target_activated = true
  end
end


function arrow_target_right:on_activated()

  if arrow_target_activated then
    map:set_entities_enabled("big_chest", true)
    sol.audio.play_sound("secret")
  else
    arrow_target_activated = true
  end
end


function switch_stairs1:on_activated()

  map:set_entities_enabled("stairs1", true)
  sol.audio.play_sound("secret")
  game:set_value("dungeon_3_floor_2_stairs1", true)
end

for walls in map:get_entities("runner") do
  function walls:on_interaction()

    hero:start_running()
  end
end
