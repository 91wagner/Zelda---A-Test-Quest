local map = ...
local game = map:get_game()

local sensor_tree_not_activated

function map:on_started()
  
  sensor_tree_activated = false

  if game:get_value("blacksmith_door") then
    house_door:set_enabled(false)
  end


  if game:get_value("dungeon_1_finished") then
    map:set_entities_enabled("to_desert", true)
  else
    map:set_entities_enabled("to_desert", false)
  end
end


function sensor_tree:on_activated()

  if hero:get_state() == "running" and not sensor_tree_activated then
    sensor_tree_activated = true
    hero:freeze()
    sol.audio.play_sound("running_obstacle")

    for i = 0, 3 do
      sol.timer.start(i*500, function()

        for entities in map:get_entities("tree") do
          local x, y, label = entities:get_position()
          entities:set_position(x, y-4, label)
          sol.audio.play_sound("bush")
        end
        if i == 3 then 
          hero:unfreeze() 
          sol.audio.play_sound("secret")
        end
      end)
    end
  end
end

