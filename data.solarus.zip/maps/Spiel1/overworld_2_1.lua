local map = ...
local game = map:get_game()


function map:on_started()

  if game:get_value("difficulty") == "easy" then
    map:set_entities_enabled("block_2", false)
    block:set_pullable(true)
  end
end