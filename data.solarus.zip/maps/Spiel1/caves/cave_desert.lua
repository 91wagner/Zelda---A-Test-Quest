local map = ...
local game = map:get_game()
local star_state

local function switch_stars()
  
  for stars in map:get_entities("star_false") do
    stars:set_enabled(star_state)
  end
  for switches in map:get_entities("switch_star_false") do
    switches:set_enabled(star_state)
  end
  
  for stars in map:get_entities("star_true") do
    stars:set_enabled(not star_state)
  end
  for switches in map:get_entities("switch_star_true") do
    switches:set_enabled(not star_state)
  end

  star_state = not star_state
end



function map:on_started()

  star_state = false
  switch_stars()
  bomb_hole_teleporter:set_enabled(false)


  if big_chest:is_open() then
    arrow_target:set_enabled(false)
  else
  map:set_entities_enabled("big_chest", false)
  end

end


function arrow_target:on_activated()

  sol.audio.play_sound("chest_appears")
  map:set_entities_enabled("big_chest", true)
end


for switches in map:get_entities("switch_star") do
  function switches:on_activated()

    sol.audio.play_sound("secret")
    switch_stars()
    
  end
end


function bomb_hole:on_collision_explosion()

  sol.audio.play_sound("secret")
  bomb_hole_closed:set_enabled(false)
  bomb_hole_teleporter:set_enabled(true)
  bomb_hole:set_enabled(false)
end