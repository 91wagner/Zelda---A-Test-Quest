local map = ...
local game = map:get_game()


local timer = nil
local finished = false
local started = false

function map:on_started()

  if not game:get_value("dungeon_2_finished") then
    boy:set_enabled(false)
  end 
  boy_2:set_enabled(false)

  if game:get_value("difficulty") == "easy" then
    map:set_entities_enabled("weg", false)
  end
end


function boy:on_interaction()

  if not started then
    
    started = true
    game:start_dialog("hole_under_hotel.boy.play", function(answer)
 
      if answer == 2 then
        if game:get_money() >= 10 then
          game:remove_money(10)
          game:start_dialog("hole_under_hotel.boy.yes", function()
   
            start_wall:set_enabled(false)
            sol.audio.play_music("mini_game")
            timer = sol.timer.start(60000, function() end)
          end)
        else
          sol.audio.play_sound("wrong")
          game:start_dialog("_shop.not_enough_money") 
          started = false       
        end
      else
        game:start_dialog("hole_under_hotel.boy.no")
        started = false
      end
    end)
  end
end


function boy_2:on_interaction()


  local finished_time = 60000 - timer:get_remaining_time()
  if finished then
    game:start_dialog("hole_under_hotel.boy.again")
  elseif timer:get_remaining_time() == 0 then
    finished = true
    game:start_dialog("hole_under_hotel.boy.totally_lost")
  elseif finished_time < 25000 then
    finished = true
    game:start_dialog("hole_under_hotel.boy.won", finished_time/1000, function()

      if game:get_value("hole_under_hotel_piece_of_heart") then
        if finished_time < 21000 then
          hero:start_treasure("rupee", 5)
        else
          if game:get_value("difficulty") == "easy" then
            hero:start_treasure("rupee", 4)
          else
            hero:start_treasure("rupee", 3)
          end
        end
      else
        hero:start_treasure("piece_of_heart")
        game:set_value("hole_under_hotel_piece_of_heart", true)
      end
    end)
  else
    finished = true
    game:start_dialog("hole_under_hotel.boy.lost", finished_time/1000)
  end
end



function sensor_boy:on_activated()

  sensor_boy:set_enabled(false)
  boy:set_enabled(false)
  boy_2:set_enabled(true)
end
