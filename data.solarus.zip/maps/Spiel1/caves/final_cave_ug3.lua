local map = ...
local game = map:get_game()


function map:on_opening_transition_finished()

  stairs:set_enabled(false)
end


function map:on_started()

  map:set_doors_open("door")
  map:set_entities_enabled("boss", false)
end


for i=1, 4 do
  local sensor = map:get_entity("room"..i)

  function sensor:on_activated()

    sensor:set_enabled(false)
    map:set_entities_enabled("boss"..i, true)
    if i==1 then
      if game:get_value("difficulty") == "easy" then
        map:get_entity("boss"..i):set_life(25)
      else
        map:get_entity("boss"..i):set_life(35)
      end
    end
    map:close_doors("door"..i)
    if i>2 then
      sol.audio.play_music("dungeon_finished")
    else
      sol.audio.play_music("boss")
    end
  end

end


function boss1:on_dying()

  sol.audio.stop_music()
  game:start_dialog("final_cave.boss1")
end


function boss1:on_dead()

  map:open_doors("door1_")
  sol.audio.play_sound("secret")
end


function boss2:on_dying()

  sol.audio.stop_music()
  if left_chest:is_open() then
    if right_chest:is_open() then
      game:start_dialog("final_cave.boss2.3")
    else
      game:start_dialog("final_cave.boss2.2")
    end
  elseif right_chest:is_open() then
    game:start_dialog("final_cave.boss2.2")
  else
    game:start_dialog("final_cave.boss2.1")
  end 
end


function boss2:on_dead()

  game:set_value("final_cave_mastered_count", game:get_value("final_cave_mastered_count") + 1)
  map:set_entities_enabled("lava", false)
  if left_chest:is_open() then
    if right_chest:is_open() then
      hero:start_treasure("rupee", 6, "final_cave_mastered_".. game:get_value("final_cave_mastered_count"), function()

        hero:teleport("Spiel1/overworld_3_4", "from_cave")
      end)
    else
      map:open_doors("door2_right")
      sol.audio.play_sound("secret")
    end
  elseif right_chest:is_open() then
    map:open_doors("door2_left")
    sol.audio.play_sound("secret")
  else
    map:open_doors("door2_")
    sol.audio.play_sound("secret")
  end
  
end


function left_chest:on_empty()

  hero:start_treasure("gold_bar", 1, "final_cave_left_big_chest_opened", function()

    hero:teleport("Spiel1/overworld_3_4", "from_cave")
  end)
end


function right_chest:on_empty()

  hero:start_treasure("tunic", 3, "final_cave_right_big_chest_opened", function()

    hero:teleport("Spiel1/overworld_3_4", "from_cave")
  end)
end

