local map = ...
local game = map:get_game()


function map:on_started()

  map:set_doors_open("door")
  if not game:get_value("woods_cave_3_bomb_door_1_open") then
    bomb_door1:set_visible(false)
  end
  if not game:get_value("woods_cave_3_bomb_door_3_open") then
    bomb_door3:set_visible(false)
  end
  if not game:get_value("woods_cave_3_bomb_door_5_open") then
    bomb_door5:set_visible(false)
  end
  if not game:get_value("woods_cave_3_bomb_door_7_open") then
    bomb_door7:set_visible(false)
  end
  if not game:get_value("woods_cave_3_bomb_door_8_open") then
    bomb_door8:set_visible(false)
  end
  if not game:get_value("woods_cave_3_bomb_door_9_open") then
    bomb_door9:set_visible(false)
  end
  if not game:get_value("woods_cave_3_bomb_door_11_open") then
    bomb_door11:set_visible(false)
  end
  if not game:get_value("woods_cave_3_bomb_door_12_open") then
    bomb_door12:set_visible(false)
  end
  if not game:get_value("woods_cave_3_bomb_door_13_open") then
    bomb_door13:set_visible(false)
  end
  if not game:get_value("woods_cave_3_bomb_door_14_open") then
    bomb_door14:set_visible(false)
  end
end

for bdoors in map:get_entities("bomb_door") do
  function bdoors:on_opened()

    sol.audio.play_sound("secret")
  end
end


function bomb_door1:on_opened()
 
  sol.audio.play_sound("secret")
end


function bomb_block_at_entrance:on_opened()

  sol.audio.play_sound("secret")
end


function bomb_chest:on_empty()

  map:close_doors("door1")
  sol.audio.play_sound("wrong")
  hero:start_treasure("bomb", 2)
end