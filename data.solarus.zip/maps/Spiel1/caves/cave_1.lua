local map = ...
local game = map:get_game()


function map:on_started()
  if chest_shield:is_open() then
    chest_shield_switch:set_activated(true)
  else
    chest_shield:set_enabled(false)
  end
  if game:get_value("difficulty") == "easy" then
    map:set_entities_enabled("weg", false)
  end
end

function chest_shield_switch:on_activated()
  sol.audio.play_sound("chest_appears")
  chest_shield:set_enabled(true)
end
