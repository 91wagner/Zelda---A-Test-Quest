local map = ...
local game = map:get_game()


function map:on_started()

  wizard:set_enabled(false)
end



function fountain:on_interaction()
 
  local stop_interaction = false
  local wizard_enabled = false

  if game:get_value("money_donated_to_fountain") == nil then
    game:set_value("money_donated_to_fountain", 0)
  elseif game:get_value("money_donated_to_fountain") >= 1000 then
    game:start_dialog("cave_in_front_of_desert.fountain_text.too_much")  
    stop_interaction = true 
  end

  if not stop_interaction then
    game:start_dialog("cave_in_front_of_desert.fountain_text.throw", function(answer)
    
      if answer == 4 and game:get_money() >= 25 then
        game:remove_money(25)
        game:set_value("money_donated_to_fountain", game:get_value("money_donated_to_fountain") + 25)

  hero:freeze()
        for i=1, 6 do
          if i<6 then
            sol.timer.start(500*i, function()
              map:create_pickable({
                x = 160,
                y = 125,
                layer = 1,
                treasure_name = "rupee",
                treasure_variant = 2, 
              })
            end)
          else
            sol.timer.start(500*i, function()
            if game:get_value("money_donated_to_fountain") < 1000 then
              game:start_dialog("cave_in_front_of_desert.fountain_text.money_thrown")
  hero:unfreeze()
            else
              sol.audio.play_music("great_fairy")
              for i=1, 9 do
                sol.timer.start(500*i, function()
                  wizard_enabled = not wizard_enabled
                  wizard:set_enabled(wizard_enabled)
                  if i==9 then
                    game:start_dialog("cave_in_front_of_desert.fountain_text.enough", function()

  hero:unfreeze()
                      hero:start_treasure("piece_of_heart", 1, "piece_of_heart_out_of_fountain")
                      wizard:set_enabled(false)
                    end)
                  end
                end)
              end
            end
            end)
          end
        end
      elseif answer == 3 and game:get_money() >= 50 then
        game:remove_money(50)
        game:set_value("money_donated_to_fountain", game:get_value("money_donated_to_fountain") + 50)

  hero:freeze()
        for i=1, 5 do
          if i<3 then
            sol.timer.start(500*i, function()
              map:create_pickable({
                x = 160,
                y = 125,
                layer = 1,
                treasure_name = "rupee",
                treasure_variant = 3, 
              })
            end)
          elseif i<5 then
            sol.timer.start(500*i, function()
              map:create_pickable({
                x = 160,
                y = 117,
                layer = 1,
                treasure_name = "rupee",
                treasure_variant = 2, 
              })
            end)
          else
            sol.timer.start(500*i, function()
            if game:get_value("money_donated_to_fountain") < 1000 then
              game:start_dialog("cave_in_front_of_desert.fountain_text.money_thrown")
  hero:unfreeze()
            else
              sol.audio.play_music("great_fairy")
              for i=1, 9 do
                sol.timer.start(500*i, function()
                  wizard_enabled = not wizard_enabled
                  wizard:set_enabled(wizard_enabled)
                  if i==9 then
                    game:start_dialog("cave_in_front_of_desert.fountain_text.enough", function()

  hero:unfreeze()
                      hero:start_treasure("piece_of_heart", 1, "piece_of_heart_out_of_fountain")
                      wizard:set_enabled(false)
                    end)
                  end
                end)
              end
            end
            end)
          end
        end
      elseif answer == 2 and game:get_money() >= 100 then
        game:remove_money(100)
        game:set_value("money_donated_to_fountain", game:get_value("money_donated_to_fountain") + 100)

  hero:freeze()
        for i=1, 6 do
          if i<6 then
            sol.timer.start(500*i, function()
              map:create_pickable({
                x = 160,
                y = 125,
                layer = 1,
                treasure_name = "rupee",
                treasure_variant = 3, 
              })
            end)
          else
            sol.timer.start(500*i, function()
            if game:get_value("money_donated_to_fountain") < 1000 then
              game:start_dialog("cave_in_front_of_desert.fountain_text.money_thrown")
  hero:unfreeze()
            else
              sol.audio.play_music("great_fairy")
              for i=1, 9 do
                sol.timer.start(500*i, function()
                  wizard_enabled = not wizard_enabled
                  wizard:set_enabled(wizard_enabled)
                  if i==9 then
                    game:start_dialog("cave_in_front_of_desert.fountain_text.enough", function()

  hero:unfreeze()
                      hero:start_treasure("piece_of_heart", 1, "piece_of_heart_out_of_fountain")
                      wizard:set_enabled(false)
                    end)
                  end
                end)
              end
            end
            end)
          end
        end
      else
        game:start_dialog("cave_in_front_of_desert.fountain_text.not_enough_money")
      end
    end)
  end
end