local map = ...

local number_of_enemies = 0


function map:on_opening_transition_finished()

  stairs:set_enabled(false)
end


function map:on_started()

  map:set_doors_open("door")
  map:set_entities_enabled("enemy", false)
  map:set_entities_enabled("tiles", false)
end


for i=1, 5 do
  local sensor = map:get_entity("room"..i)

  function sensor:on_activated()

    sensor:set_enabled(false)
    map:set_entities_enabled("enemy"..i, true)
    map:close_doors("door"..i)
    map:set_entities_enabled("tiles"..i, true)
    number_of_enemies = map:get_entities_count("enemy"..i)
  end

end


for j=1,5 do
  for enemies in map:get_entities("enemy"..j) do

    function enemies:on_dead()

      number_of_enemies = number_of_enemies - 1
      if number_of_enemies == 0 then
        map:open_doors("door"..j.."_")
        sol.audio.play_sound("secret")
      end
    end
  end
end