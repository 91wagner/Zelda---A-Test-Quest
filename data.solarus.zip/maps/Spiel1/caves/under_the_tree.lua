local map = ...



for i = 1, map:get_entities_count("sensor") / 2 do
  local sensor = map:get_entity("sensor_a_" .. i)

  function sensor:on_activated()
    local x, y, layer = hero:get_position()
    local x_a, y_a = sensor:get_position()
    local x_b, y_b = map:get_entity("sensor_b_" .. i):get_position()
    
    hero:set_position(x + x_b - x_a, y + y_b - y_a, layer)
    
  end

end


function door1:on_opened()

  sol.audio.play_sound("secret")
end


function door2:on_opened()

  sol.audio.play_sound("secret")
end