local map = ...
local game = map:get_game()
local arrow_target_hits = 0

function map:on_started()

  local torches_lit = false
  if not chest:is_open() then
    chest:set_enabled(false)
  end

  arrow_target_hits = 0
  bridge:set_enabled(false)

end


for i = 1, 8 do

  local entity = map:get_entity("torch_" .. i)
  function entity:on_collision_fire()

    if light_torch("torch_", i, 0) and not torches_lit then
      torches_lit = true
      if not chest:is_open() then
        sol.audio.play_sound("secret")
        chest:set_enabled(true)
      end
    end
  end
end


for arrow_targets in map:get_entities("arrow_target") do
  function arrow_targets:on_activated()

    if arrow_target_hits == 3 then
      bridge:set_enabled(true)
      sol.audio.play_sound("secret")
    else
      arrow_target_hits = arrow_target_hits + 1
    end
  end
end






function unten_rechts:on_activated()

  local x, y, layer = oben_links:get_position()
  hero:set_position(x,y,layer)
end

function unten_links:on_activated()

  local x, y, layer = oben_rechts:get_position()
  hero:set_position(x,y,layer)
end

function oben_rechts:on_activated()

  local x, y, layer = unten_links:get_position()
  hero:set_position(x,y,layer)
end

function oben_links:on_activated()

  local x, y, layer = unten_rechts:get_position()
  hero:set_position(x,y,layer)
end










-- entzündet die Fackel mit dem Namen 'torch_prefix' .. 'torch_number' für eine Zeit 'time' und überprüft, ob alle Fackeln mit dem Präfix 'torch_prefix' entzündet sind. Wenn dies der Fall ist, liefert die Funktion 'true' zurück, ansonsten 'false'
function light_torch(torch_prefix, torch_number, time)

  local sprite = map:get_entity(torch_prefix .. torch_number):get_sprite()

  if sprite:get_animation() == "unlit" then
    sprite:set_animation("lit")
    if time > 0 then
      sol.timer.start(time, function()
        sprite:set_animation("unlit")
      end)
    end
  end
 
  local all_lit = true
  
  for entities in map:get_entities(torch_prefix) do
    local sprites = entities:get_sprite()
    all_lit = all_lit and sprites:get_animation() == "lit"
  end

  return all_lit
end
