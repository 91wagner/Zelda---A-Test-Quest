local map = ...
local game = map:get_game()

local number_of_enemies = 0
local switches_activated = 0
local switches_room_5 = 6



function map:on_opening_transition_finished()

  stairs:set_enabled(false)
  game:set_value("is_dark", false)
end



function map:on_started()

  map:set_doors_open("door")
  map:set_entities_enabled("enemy", false)
  map:set_entities_enabled("tiles", false)
  switches_activated = 0
  switches_room_5 = 6
  game:set_value("is_dark", false)
end


for i=1, 5 do
  local sensor = map:get_entity("room"..i)

  function sensor:on_activated()

    sensor:set_enabled(false)
    map:set_entities_enabled("enemy"..i, true)
    map:close_doors("door"..i)
    map:set_entities_enabled("tiles"..i, true)
    number_of_enemies = map:get_entities_count("enemy"..i)
    if i==2 then
      hero:save_solid_ground()
    end
    if i==3 then
      game:set_value("is_dark", true)
      hero:save_solid_ground()
    end
    if i==4 then
      game:set_value("is_dark", false)
      hero:reset_solid_ground()
    end
  end

end


for j=1,5 do
  for enemies in map:get_entities("enemy"..j) do

    function enemies:on_dead()

      number_of_enemies = number_of_enemies - 1
      if number_of_enemies == 0 then
        map:open_doors("door"..j.."_")
        sol.audio.play_sound("secret")
      end
    end
  end
end


-- switch puzzle

for k=1,8 do
  local switches = map:get_entity("switch"..k)

  function switches:on_activated() 

    switches_activated = switches_activated + 1
    if switches_activated ~= k then    
      sol.audio.play_sound("wrong")
      map:create_enemy({
        breed = "red_bullblin",
        direction = 3,
        layer = 1,
        x = 152,
        y = 352
      })
      for de_switches in map:get_entities("switch") do
        de_switches:set_activated(false)
      end
      switches_activated = 0
    elseif k<8 then
      sol.audio.play_sound("magic_bar")
    elseif k==8 then
      sol.audio.play_sound("secret")
      map:open_doors("door1_")
    end
  end
end


function switch_room_2:on_activated()

  map:open_doors("door2_")
end


function switch_room_2:on_inactivated()

  map:close_doors("door2_")
end


function switch_room3:on_activated()

  map:open_doors("door3_")
  sol.audio.play_sound("secret")
end


function switch_room4:on_activated()

  map:open_doors("door4_")
  sol.audio.play_sound("secret")
end


function switch_room4_2:on_activated()

  sol.audio.play_sound("secret")

  if torch_wall:is_enabled() then
    map:set_entities_enabled("torch_wall",false)
  else
    map:set_entities_enabled("torch_wall",true)
  end
end


for walls in map:get_entities("wall") do
  function walls:on_interaction()

    hero:start_running()
  end
end



-- room5
for torches in map:get_entities("torch5") do
  function torches:on_collision_fire()

    local sprite_torch = torches:get_sprite()
    if sprite_torch:get_animation() == "unlit" then
      switches_room_5 = switches_room_5 - 1
      sprite_torch:set_animation("lit")

      sol.timer.start(map, 20000, function()
      
        sprite_torch:set_animation("unlit")
        switches_room_5 = switches_room_5 + 1
      end)
    end
  end
end

for arrow_targets in map:get_entities("arrow_target") do
  function arrow_targets:on_activated() 

    switches_room_5 = switches_room_5 - 1
  end
end


function switch_room5:on_activated()

  if switches_room_5 == 0 then
    switch_room5:set_locked(true)
    sol.timer.stop_all(map)
    map:open_doors("door5_")
    sol.audio.play_sound("secret")
  end
end

