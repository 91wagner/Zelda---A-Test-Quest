local map = ...
local game = map:get_game()


function map:on_started()

  if game:get_value("difficulty") == "easy" then
    gegner:set_enabled(false)
    block:set_maximum_moves(1)
  end
end


