local map = ...
local game = map:get_game()


function map:on_started()

  map:set_entities_enabled("waterdrain1_full_jumpers", false)

  if chest_small_key:is_open() then
    chest_small_key:set_enabled(true)
  else
    chest_small_key:set_enabled(false)
  end

  map:set_doors_open("door_enemies_killed", true)
  if game:get_value("difficulty") == "easy" then
    fireball_thrower_for_chest:set_enabled(false)
    feuerrad:set_enabled(false)
  end
end






local function water_drain(drain_number, camera_x, camera_y)
  hero:freeze()
  map:set_entities_enabled("waterdrain".. drain_number .. "_empty_jumpers", true)
  map:set_entities_enabled("waterdrain".. drain_number .. "_full_jumpers", false)
  
  map:move_camera(camera_x, camera_y, 104, function()
    map:set_entities_enabled("water_drain", true)
    sol.audio.play_sound("secret")

    sol.timer.start(300, function()
      sol.audio.play_sound("water_drain_begin")
      for i=1,4 do

        sol.timer.start(500*i, function()
          map:set_entities_enabled("waterdrain" .. drain_number .. "_" .. 5-i, false)
          if i < 4 then
            map:set_entities_enabled("waterdrain" .. drain_number .. "_" .. 4-i, true)
          else
            hero:unfreeze()
            map:set_entities_enabled("stairs_waterdrain" .. drain_number, true) 
          end
          sol.audio.play_sound("water_drain")
        end)

      end
    end)


  end, 300, 2600)
end


local function water_fill(drain_number, camera_x, camera_y)
  hero:freeze()
  map:set_entities_enabled("waterdrain".. drain_number .. "_empty_jumpers", false)
  map:set_entities_enabled("waterdrain".. drain_number .. "_full_jumpers", true)

  map:move_camera(camera_x, camera_y, 104, function()
  map:set_entities_enabled("water_drain", false)
  sol.audio.play_sound("secret")

  sol.timer.start(300, function()

    sol.audio.play_sound("water_fill_begin")
    for i=1,4 do
      sol.timer.start(500*i, function()
        
        map:set_entities_enabled("waterdrain" .. drain_number .. "_" .. i, true)
        if i>1 then
          map:set_entities_enabled("waterdrain" .. drain_number .. "_" .. i-1, false)
        end
        if i == 4 then
          hero:unfreeze()
          map:set_entities_enabled("stairs_waterdrain" .. drain_number, false) 
        end
        sol.audio.play_sound("water_fill")
      end)
    end
  end)


  end, 300, 2600)

end




function switch_water_fill1_1:on_activated()
  
  if not waterdrain1_4_1:is_enabled() then
    water_fill(1, 464, 216)
    map:set_entities_enabled("enemy_drown", false)
  else
    sol.audio.play_sound("wrong")
  end
end


function switch_water_drain1_1:on_activated()
  
  if waterdrain1_4_1:is_enabled() then
    water_drain(1, 464, 216)
    map:set_entities_enabled("enemy_drown", true)
  else
    sol.audio.play_sound("wrong")
  end
end


for enemies_for_chest in map:get_entities("enemy_for_chest") do
  function enemies_for_chest:on_dead() 

    if not map:has_entities("enemy_for_chest") then
      if not chest_small_key:is_open() then
        chest_small_key:set_enabled(true)
      end
      sol.audio.play_sound("secret")
      if game:get_value("difficulty") ~= "easy" then
        fireball_thrower_for_chest:set_life(0)
      end
      map:open_doors("door_enemies_killed")
    end
  end
end


function sensor_close_door:on_activated()
  if map:has_entities("enemy_for_chest") then
    map:close_doors("door_enemies_killed")
  end
end
