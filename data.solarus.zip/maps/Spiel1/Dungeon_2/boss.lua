local map = ...
local game = map:get_game()


function map:on_started()

  if game:get_value("difficulty") == "easy" then
    map:set_entities_enabled("weg", false)    
  end

  map:set_doors_open("door")
  map:set_entities_enabled("billy", false)
  if game:get_value("dungeon_2_finished") then
    shop_man:set_enabled(false)
    final:set_enabled(false)
  end
  if game:get_value("dungeon_2_boss_defeated") then
    map:set_entities_enabled("sensor", false)
    map:set_entities_enabled("immer_da", false)
    map:set_entities_enabled("weg", false)
    map:set_entities_enabled("pike", false)
    sol.audio.play_music("dark_world_dungeon")
  end
  
end




function sensor_room1:on_activated()
  
  if door_entrance:is_open() then
    billy_1:set_enabled(true)
    local sprite = billy_1:get_sprite()
    sprite:set_direction(1)
    map:close_doors("door_entrance")
    game:start_dialog("dungeon.2.billy.1", function()

      sol.audio.play_music("boss")
    end)
  end 
end


function billy_1:on_dying()

  map:set_entities_enabled("weg1", false)
  map:set_entities_enabled("immer_da1", false)
end

function billy_1:on_dead()

  map:open_doors("door_entrance_2")
  sol.audio.stop_music()
end



function sensor_room2:on_activated()
  if door_room2:is_open() then
    wall:set_enabled(false)
    billy_2:set_enabled(true)
    local sprite = billy_2:get_sprite()
    sprite:set_direction(2)
    map:close_doors("door_room2")
    game:start_dialog("dungeon.2.billy.2", function()

      sol.audio.play_music("boss")
      sol.timer.start(1000, function()
        wall_2:set_enabled(false)
      end)
    end)
  end
end  


function billy_2:on_dying()

  map:set_entities_enabled("weg2", false)
  map:set_entities_enabled("immer_da2", false)
end


function billy_2:on_dead()

  map:open_doors("door_room2_2")
  sol.audio.stop_music()
  wall:set_enabled(true)
end





function sensor_room3:on_activated()

  if door_room3:is_open() then
    billy_3:set_enabled(true)
    local sprite = billy_3:get_sprite()
    sprite:set_direction(3)
    map:close_doors("door_room3")
    game:start_dialog("dungeon.2.billy.3", function()

      sol.audio.play_music("boss")
      sol.timer.start(1000, function()
        map:set_entities_enabled("room_3_wall", false)
      end)
    end)
  end
end  

if not game:get_value("dungeon_2_boss_defeated") then

  function billy_3:on_dying()

    map:set_entities_enabled("weg3", false)
    map:set_entities_enabled("immer_da3", false)
  end


  function billy_3:on_dead()

    map:open_doors("door_room3_2")
    sol.audio.stop_music()
    map:set_entities_enabled("pike", false)
    sol.audio.play_sound("secret")
    map:set_entities_enabled("room_3_wall", true)
  end 

end





function final:on_activated()

  sol.audio.play_music("dungeon_finished")
  hero:freeze()
  hero:set_walking_speed(64)
  hero:walk("444466666644444444444422222222")
  
  sol.timer.start(3550, function()

    hero:set_walking_speed(88)
    game:start_dialog("dungeon.2.shop_man", function()
      
      sol.audio.stop_music()
      sol.audio.play_music("victory")
      hero:freeze()
      sol.timer.start(8500, function()
        hero:unfreeze()
        hero:start_victory(function()
          hero:freeze()
          sol.timer.start(500, function()
            sol.audio.play_sound("world_warp")
            hero:teleport("Spiel1/overworld_5_6", "dungeon_2_entrance")
            hero:unfreeze()
            game:set_value("dungeon_2_finished", true)
          end)
        end)
      end)
    end)
  end)
end












