local map = ...
local game = map:get_game()


function map:on_started()

  stairs_waterdrain1:set_enabled(false)

  stairs_waterdrain2_1:set_enabled(false)
  stairs_waterdrain2_2:set_enabled(false)
end


local function water_drain(drain_number, camera_x, camera_y)
  hero:freeze()
  
  map:move_camera(camera_x, camera_y, 104, function()
    map:get_entity("water_drain" .. drain_number):set_enabled(true)
    sol.audio.play_sound("secret")

    sol.timer.start(300, function()
      sol.audio.play_sound("water_drain_begin")
      for i=1,4 do

        sol.timer.start(500*i, function()
          map:get_entity("waterdrain" .. drain_number .. "_" .. 5-i):set_enabled(false)
          if i < 4 then
            map:get_entity("waterdrain" .. drain_number .. "_" .. 4-i):set_enabled(true)
          else
            hero:unfreeze()
            map:set_entities_enabled("stairs_waterdrain" .. drain_number, true) 
          end
          sol.audio.play_sound("water_drain")
        end)

      end
    end)


  end, 300, 2600)
end


local function water_fill(drain_number, camera_x, camera_y)
  hero:freeze()
  
  map:move_camera(camera_x, camera_y, 104, function()
  map:get_entity("water_drain" .. drain_number):set_enabled(false)
  sol.audio.play_sound("secret")

  sol.timer.start(300, function()
    sol.audio.play_sound("water_fill_begin")
    for i=1,4 do
      sol.timer.start(500*i, function()
        if i>1 then
          map:get_entity("waterdrain" .. drain_number .. "_" .. i-1):set_enabled(false)
        end
        map:get_entity("waterdrain" .. drain_number .. "_" .. i):set_enabled(true)
        if i == 4 then
          hero:unfreeze()
          map:set_entities_enabled("stairs_waterdrain" .. drain_number, false) 
        end
        sol.audio.play_sound("water_fill")
      end)
    end
  end)


  end, 300, 2600)

end



function switch_waterdrain1:on_activated()

  water_drain(1, 160, 560)  
end


function switch_waterdrain2:on_activated()

  if waterdrain2_4:is_enabled() then
    water_drain(2, 160, 360)
  else
    sol.audio.play_sound("wrong")
  end
end


function switch_waterfill2:on_activated()

  if not waterdrain2_4:is_enabled() then
    water_fill(2, 160, 360)
  else
    sol.audio.play_sound("wrong")
  end
end


function switch_waterdrain2_2:on_activated()

  if waterdrain2_4:is_enabled() then
    water_drain(2, 160, 360)
  end
end







