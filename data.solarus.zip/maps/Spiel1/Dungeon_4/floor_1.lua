local map = ...

nb_enemies_door1 = 0


function map:on_started()

  nb_enemies_door1 = 5
  map:set_doors_open("door1")
  map:set_entities_enabled("enemy_door1", false)


  if chest_small_key:is_open() then
    switch1:set_activated()
    switch2:set_activated()
    switch3:set_activated()
    switch4:set_activated()
  else
    chest_small_key:set_enabled(false)
  end
end

-- close door 1
for sensors in map:get_entities("door1_closer") do
  function sensors:on_activated()
    
    map:set_entities_enabled("door1_closer", false)
    map:set_entities_enabled("enemy_door1", true)
    map:close_doors("door1")
  end
end


-- open door 1
for enemies in map:get_entities("enemy_door1") do
  function enemies:on_dead()

    nb_enemies_door1 = nb_enemies_door1 - 1
    if nb_enemies_door1 <= 0 then
      sol.audio.play_sound("secret")
      map:open_doors("door1")
      fireball_thrower:set_life(0)
    end
  end
end



-- handle the switch puzzle
function switch1:on_activated()

  sol.audio.play_sound("magic_bar")
end


function switch2:on_activated()

  if not switch1:is_activated() then
    sol.audio.play_sound("wrong")
    map:create_enemy({
      breed = "red_bullblin",
      direction = 3,
      layer = 1,
      x = 152,
      y = 128
    })
    switch2:set_activated(false)
  else
    sol.audio.play_sound("magic_bar")
  end
end


function switch3:on_activated()

  if not switch2:is_activated() then
    sol.audio.play_sound("wrong")
    map:create_enemy({
      breed = "red_bullblin",
      direction = 3,
      layer = 1,
      x = 152,
      y = 128
    })
    switch1:set_activated(false)
    switch3:set_activated(false)
  else
    sol.audio.play_sound("magic_bar")
  end
end


function switch4:on_activated()

  if not switch3:is_activated() then
    sol.audio.play_sound("wrong")
    map:create_enemy({
      breed = "red_bullblin",
      direction = 3,
      layer = 1,
      x = 152,
      y = 128
    })
    switch1:set_activated(false)
    switch2:set_activated(false)
    switch4:set_activated(false)
  else
    chest_small_key:set_enabled(true)
    sol.audio.play_sound("chest_appears")
  end
end