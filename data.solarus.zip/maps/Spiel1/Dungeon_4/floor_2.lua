local map = ...
local game = map:get_game()

function map:on_started()

  hole_teleporter:set_enabled(false)

  game:set_value("is_dark", false)
end

function hole:on_collision_explosion()

  sol.audio.play_sound("secret")
  hole_closed:set_enabled(false)
  hole_teleporter:set_enabled(true)
  hole:set_enabled(false)
end