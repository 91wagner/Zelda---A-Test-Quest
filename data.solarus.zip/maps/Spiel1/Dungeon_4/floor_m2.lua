local map = ...
local game = map:get_game()
local hero = map:get_entity("hero")

local ganon_defeated = false
local restart_game = false

function map:on_started()

  ganon:set_enabled(false)
  for torches in map:get_entities("torch") do
    torches:get_sprite():set_animation("lit")
  end
  hero:set_direction(1)
  game:set_value("is_dark", false)
  ganon_defeated = false
end

function map:on_opening_transition_finished()

  game:start_dialog("ganon.1", function()
    
    ganon:set_enabled(true)
    zelda_npc:set_enabled(false)
    ganon_npc:set_enabled(false)
  end)
end


function ganon:on_dead()

  sol.timer.stop_all(map)
  sol.audio.play_music("zelda")
  game:set_value("ganon_defeated", true)
  sol.timer.start(1000, function()
 
    hero:teleport("Spiel1/Dungeon_4/credits_room", "entrance", "immediate")
  end)
end

