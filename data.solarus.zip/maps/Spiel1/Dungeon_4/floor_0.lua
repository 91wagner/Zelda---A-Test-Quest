local map = ...

local nb_enemies_door1 = 0
local nb_enemies_door2 = 0

function map:on_started()

  map:set_doors_open("door1")
  nb_enemies_door1 = 2
  map:set_entities_enabled("enemy_door1", false)

  map:set_doors_open("door2")
  nb_enemies_door2 = 5
  map:set_entities_enabled("enemy_door2", false)

-- kleine Truhe oben links
  if chest_small_key:is_open() then
    arrow_target:set_activated()
  else
    chest_small_key:set_enabled(false)
  end
end

-- close door 1
for sensors in map:get_entities("door1_closer") do
  function sensors:on_activated()
    
    map:set_entities_enabled("door1_closer", false)
    map:set_entities_enabled("enemy_door1", true)
    map:close_doors("door1")
  end
end

-- open door 1
for enemies in map:get_entities("enemy_door1") do
  function enemies:on_dead()

    nb_enemies_door1 = nb_enemies_door1 - 1
    if nb_enemies_door1 <= 0 then
      sol.audio.play_sound("secret")
      map:open_doors("door1")
    end
  end
end



-- close door 2
for sensors in map:get_entities("door2_closer") do
  function sensors:on_activated()
    
    map:set_entities_enabled("door2_closer", false)
    map:set_entities_enabled("enemy_door2", true)
    map:close_doors("door2")
  end
end

-- open door 2
for enemies in map:get_entities("enemy_door2") do
  function enemies:on_dead()

    nb_enemies_door2 = nb_enemies_door2 - 1
    if nb_enemies_door2 <= 0 then
      sol.audio.play_sound("secret")
      map:open_doors("door2")
    end
  end
end


-- kleine Truhe oben links aktivieren
function arrow_target:on_activated()

  sol.audio.play_sound("chest_appears")
  chest_small_key:set_enabled(true)
end
