local map = ...
local game = map:get_game()

local dst_surface = nil

function map:on_started()

  hero:freeze()
  dst_surface = sol.surface.create(340,280)
end



local function rebuild_surface()

  if ganon_defeated then
    
    dst_surface:fill_color({0, 0, 0})

    local text = sol.text_surface.create({
      horizontal_alignment = "center",
      font_size = 48,
      text = "Vielen Dank fürs Spielen!",
    })

    text:draw(dst_surface, 190, 60)

    local herzen = sol.text_surface.create({
      fint_size = 14,
      text = "Herzen:  " .. game:get_max_life()/4 .."/".. game:get_value("nb_hearts_per_row")*2,
    })
   
    herzen:draw(dst_surface, 50, 90)

    local hat_bumerang 
    if game:get_item("boomerang"):get_variant() == 2 then
      hat_bumerang = "Ja"
    else
      hat_bumerang = "Nein"
    end
    local bumerang = sol.text_surface.create({
      font_size = 14,
      text = "Roter Bumerang:  " .. hat_bumerang,
    })

    bumerang:draw(dst_surface, 50, 105)

    local hat_schwert
    if game:get_item("sword"):get_variant() == 4 then
      hat_schwert = "Ja"
    else
      hat_schwert = "Nein"
    end
    local schwert = sol.text_surface.create({
      font_size = 14,
      text = "Goldenes Schwert:  " .. hat_schwert,
    })

    schwert:draw(dst_surface, 50, 120)

    local hat_ruestung
    if game:get_item("tunic"):get_variant() == 3 then
      hat_ruestung = "Ja"
    else
      hat_ruestung = "Nein"
    end
    local ruestung = sol.text_surface.create({
      font_size = 14,
      text = "Rote Rüstung:  " .. hat_ruestung,
    })

    ruestung:draw(dst_surface, 50, 135)

    local koecher = sol.text_surface.create({
      font_size = 14,
      text = "Köcher:  " .. game:get_item("quiver"):get_variant() .. "/2",
    })

    koecher:draw(dst_surface, 50, 150)


    local bomben = sol.text_surface.create({
      font_size = 14,
      text = "Bomben-Taschen:  " .. game:get_item("bomb_bag"):get_variant() .. "/2",
    })

    bomben:draw(dst_surface, 50, 165)

    local hoehle = sol.text_surface.create({
      font_size = 14,
      text = "Höhle der Schmerzen:  " .. game:get_value("final_cave_mastered_count") .. " Mal",
    })

    hoehle:draw(dst_surface, 50, 180)

    local zeit_min = game:get_value("play_time") % 60
    local zeit_std = (game:get_value("play_time")-zeit_min) / 60
    local zeit = sol.text_surface.create({
      font_size = 14,
      text = "Spielzeit:  " ..(zeit_std - (zeit_std % 10))/10 .. (zeit_std % 10) ..":".. (zeit_min - (zeit_min % 10))/10 .. (zeit_min % 10),
    })

    zeit:draw(dst_surface, 50, 195)

    local number_deaths = game:get_value("nb_deaths")
    local deaths = sol.text_surface.create({
      font_size = 14,
      text = "Tode:  "..number_deaths
    })

    deaths:draw(dst_surface, 50, 210)

    local spiel_rang_text
    if game:get_value("play_time") < 150 and game:get_item("sword"):get_variant() == 4 and game:get_item("tunic"):get_variant() == 3 and game:get_item("boomerang"):get_variant() == 2 and game:get_max_life() == game:get_value("nb_hearts_per_row")*8 and game:get_item("quiver"):get_variant() == 2 and game:get_item("bomb_bag"):get_variant() == 2 and game:get_value("final_cave_mastered_count") > 2 and game:get_value("nb_deaths") <= 5 then
      spiel_rang_text = "S"
    elseif game:get_value("play_time") < 180 and game:get_item("sword"):get_variant() == 4 and game:get_item("tunic"):get_variant() == 3 and game:get_item("boomerang"):get_variant() == 2 and game:get_max_life() == game:get_value("nb_hearts_per_row")*8 and game:get_item("quiver"):get_variant() == 2 and game:get_item("bomb_bag"):get_variant() == 2 and game:get_value("nb_deaths") < 10 then
      spiel_rang_text = "A"
    elseif game:get_value("play_time") < 240 and game:get_value("final_cave_mastered_count") > 0 and game:get_item("boomerang"):get_variant() == 2 and game:get_max_life() == game:get_value("nb_hearts_per_row")*8 - 4 and game:get_item("quiver"):get_variant() == 2 and game:get_item("bomb_bag"):get_variant() == 2 and game:get_value("nb_deaths") < 15 then
      spiel_rang_text = "B"
    elseif game:get_value("play_time") < 240 and game:get_item("boomerang"):get_variant() == 2 and game:get_max_life() == game:get_value("nb_hearts_per_row")*8 - 8 and game:get_item("quiver"):get_variant() == 2 and game:get_item("bomb_bag"):get_variant() == 2 and game:get_value("nb_deaths") < 20 then
      spiel_rang_text = "C"
    elseif game:get_value("play_time") < 300 and game:get_value("nb_deaths") < 20 then
      spiel_rang_text = "D"
    else
      spiel_rang_text = "E"
    end

    if game:get_value("difficulty") == "easy" then
      spiel_rang_text = spiel_rang_text .. "  (einfach)"
    else
      spiel_rang_text = spiel_rang_text .. "  (normal)"
    end

    local spiel_rang = sol.text_surface.create({
      font_size = 14,
      text = "Rang:  " .. spiel_rang_text,
    })

    spiel_rang:draw(dst_surface, 80, 235)
  end
end

function map:on_opening_transition_finished()
  
  hero:freeze()
  game:set_starting_location("Spiel1/overworld_1_1")
  game:start_dialog("_zelda.game_finished", function(answer)
    
    hero:freeze()
    game:set_life(game:get_max_life())
    if answer == 2 then
      sol.audio.play_sound("danger")
      game:save()
    end
    sol.audio.play_music("victory") 
    sol.timer.start(11500, function()
      sol.audio.play_music("credits")
        
    end)

    sol.timer.start(8500, function()

      hero:start_victory(function()

        ganon_defeated = true
        rebuild_surface()
        sol.timer.start(2000, function() 

          restart_game = true 
        end)
      end)
    end)
  end)
end



function map:on_draw(surface)

  dst_surface:draw(surface, -10, -20)
end




function game:on_key_pressed(key, mod)

  if ganon_defeated and restart_game then
    ganon_defeated = false
    restart_game = false
    game:start()
  end
end

