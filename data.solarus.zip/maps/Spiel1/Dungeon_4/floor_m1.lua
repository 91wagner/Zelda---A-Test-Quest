local map = ...
local game = map:get_game()

local nb_gibdos = 0
local nb_dragons = 0
local nb_bumpers = 0
local nb_tentakeln = 0
local nb_ritter = 0

function map:on_started()

  nb_gibdos = 2
  nb_dragons = 5
  nb_bumpers = 3
  nb_tentakeln = 5
  nb_ritter = 4
  khotor:set_enabled(false)

  if game:get_value("dungeon_4_khotor_defeated") then
    sensor_door5:set_enabled(false)
  end

  map:set_doors_open("door6")
end

for gibdos in map:get_entities("gibdo") do
  function gibdos:on_dead()
    
    nb_gibdos = nb_gibdos - 1
    if nb_gibdos == 0 then
      map:open_doors("door1")
      sol.audio.play_sound("secret")
    end
  end
end


for dragons in map:get_entities("dragon") do
  function dragons:on_dead()
    
    nb_dragons = nb_dragons - 1
    if nb_dragons == 0 then
      map:open_doors("door2")
      sol.audio.play_sound("secret")
    end
  end
end


for bumpers in map:get_entities("bumper") do
  function bumpers:on_dead()
    
    nb_bumpers = nb_bumpers - 1
    if nb_bumpers == 0 then
      map:open_doors("door3")
      sol.audio.play_sound("secret")
    end
  end
end


for tentakeln in map:get_entities("tentakel") do
  function tentakeln:on_dead()
    
    nb_tentakeln = nb_tentakeln - 1
    if nb_tentakeln == 0 then
      map:open_doors("door4")
      sol.audio.play_sound("secret")
    end
  end
end


for ritters in map:get_entities("ritter") do
  function ritters:on_dead()
    
    nb_ritter = nb_ritter - 1
    if nb_ritter == 0 then
      map:open_doors("door5")
      sol.audio.play_sound("secret")
    end
  end
end


function sensor_door5:on_activated()

  map:close_doors("door5")
  sol.audio.play_music("Boss")
  khotor:set_enabled(true)
  map:get_entity("khotor"):set_life(48)
  sensor_door5:set_enabled(false)
end


function khotor:on_dead()

  sol.audio.play_music("Castle")
  map:open_doors("door5")
  game:set_value("dungeon_4_khotor_defeated", true)
  sol.audio.play_sound("secret")
end


for sensors in map:get_entities("sensor_door6") do
  function sensors:on_activated()

    map:set_entities_enabled("sensor_door6", false)
    map:close_doors("door6")
  end
end


function door_switch:on_activated()

  map:open_doors("door6")
  sol.audio.play_sound("secret")
end

