local item = ...
local game = item:get_game()

function item:on_created()
  item:set_brandish_when_picked(false)
  item:set_can_disappear(true)
  item:set_shadow("small")
end

function item:on_started()
  item:set_obtainable(game:has_item("bow"))
end

function item:on_obtaining(variant, savegame_variable)
  local bow = game:get_item("bow")

  math.random(100)   
  local amounts = {1, 5, 10}
  local amount = amounts[variant]

  bow:add_amount(amount)
  
end
