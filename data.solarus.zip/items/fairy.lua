local item = ...
local game = item:get_game()

function item:on_created()
  item:set_can_disappear(true)
  item:set_brandish_when_picked(false)
  item:set_sound_when_picked("cursor")
end


function item:on_pickable_created(pickable)

  pickable:set_visible(false)
  local pick_x, pick_y, pick_layer = pickable:get_position() 
  local map = pickable:get_map()

  pickable:remove()

  map:create_enemy({name = "fairy", layer = pick_layer, x = pick_x, y = pick_y, direction = 0, breed = "fairy"})
end

function item:on_obtaining(variant, savegame_variable)
  if game:get_value("fairy_possessed") or not game:has_item("empty_bottle") then
    game:add_life(24)
  else
    game:set_value("fairy_possessed", true)
    game:start_dialog("fairy_captured")
  end
end

