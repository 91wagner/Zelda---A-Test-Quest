local item = ...

function item:on_created()
  self:set_savegame_variable("possession_flippers")
end

function item:on_obtaining()
  self:get_game():set_ability("swim", 1)
end