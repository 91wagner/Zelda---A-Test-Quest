local item = ...
local game = item:get_game()

local prob_easy = require("scripts/menus/probabilities_for_random_pickable_easy")
local prob = require("scripts/menus/probabilities_for_random_pickable")



function item:on_created()
  
  item:set_brandish_when_picked(false)
  item:set_can_disappear(true)
  item:set_shadow(nil)

end


function item:on_pickable_created(pickable)
  pickable:set_visible(false)
  local pick_x, pick_y, pick_layer = pickable:get_position() 
  local map = pickable:get_map()
  
  pickable:remove()

  local probability = math.random(1000) 

  if game:get_value("difficulty") == "easy" then
    for i=1, #prob.sum do
      if probability <= prob.sum[i] then
        map:create_pickable({name = "random_pickable_" .. prob.treasure[i] .. "_" .. prob.variant[i], layer = pick_layer, x = pick_x, y = pick_y, treasure_name = prob.treasure[i], treasure_variant = prob.variant[i]})
        break
      end
    end
  else
    for i=1, #prob_easy.sum do
      if probability <= prob_easy.sum[i] then
        map:create_pickable({name = "random_pickable_" .. prob_easy.treasure[i] .. "_" .. prob_easy.variant[i], layer = pick_layer, x = pick_x, y = pick_y, treasure_name = prob_easy.treasure[i], treasure_variant = prob_easy.variant[i]})
        break
      end
    end
  end


end