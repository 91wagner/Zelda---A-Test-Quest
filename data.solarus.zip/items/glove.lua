local item = ...
local game = item:get_game()

function item:on_created()
  item:set_savegame_variable("possession_glove")
end

function item:on_obtaining(variant, savegame_variable)
  game:set_ability("lift", variant + 1)
end