local item = ...
local game = item:get_game()

function item:on_created()
  item:set_savegame_variable("possession_boomerang")
  item:set_assignable(true)
end


function item:on_using()
  local hero = item:get_map():get_entity("hero")
  hero:start_boomerang(80 * item:get_variant() * item:get_variant(), 180, "boomerang" .. item:get_variant(), "entities/boomerang" .. item:get_variant() )
end

