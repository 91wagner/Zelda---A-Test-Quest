local piece_of_heart = ... 
local game = piece_of_heart:get_game()

function piece_of_heart:on_created()
  piece_of_heart:set_brandish_when_picked(true)
  piece_of_heart:set_sound_when_brandished("piece_of_heart")
end

function piece_of_heart:on_obtained(variant, savegame_variable)
  local nb_piece_of_heart = game:get_value("nb_piece_of_heart")
  nb_piece_of_heart = nb_piece_of_heart + 1
  game:start_dialog("_treasure.piece_of_heart." .. nb_piece_of_heart + 1)

  if nb_piece_of_heart == 4 then
    nb_piece_of_heart = 0
    game:add_max_life(4)
    game:set_life(game:get_max_life())
  end
  
  game:set_value("nb_piece_of_heart", nb_piece_of_heart)
end


