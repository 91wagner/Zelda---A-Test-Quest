local item = ...
local game = item:get_game()

function item:on_created()
  item:set_savegame_variable("possession_bow")
  item:set_amount_savegame_variable("amount_bow")
  item:set_assignable(true)
end


function item:on_obtaining(variant, savegame_variable)
  local quiver = game:get_item("quiver")
  if not quiver:has_variant() then
    quiver:set_variant(1)
  end
  item:set_amount(item:get_max_amount())
end


function item:on_using()
  if item:get_amount() == 0 then
    sol.audio.play_sound("wrong")
  else
    item:remove_amount(1)
    local hero = game:get_map():get_entity("hero")
    hero:start_bow()
  end
  item:set_finished()
end


function item:on_amount_changed(amount)
  if item:has_variant() then
    if amount == 0 then
      item:set_variant(1)
    else
      item:set_variant(2)
    end
  end
end