local heart_container = ...
local game = heart_container:get_game()

function heart_container:on_created()
  heart_container:set_brandish_when_picked(true)
  heart_container:set_sound_when_brandished("heart_container")
  heart_container:set_sound_when_picked("heart_container")
end

function heart_container:on_obtained(variant, savegame_variable)
  game:add_max_life(4)
  game:set_life(game:get_max_life())
end
