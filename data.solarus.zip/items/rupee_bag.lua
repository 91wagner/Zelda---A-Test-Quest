local item = ...
local game = item:get_game()

function item:on_created()
  item:set_savegame_variable("possession_rupee_bag")
end

function item:on_obtained(variant, savegame_variable)
  local max_moneys = {200, 500, 999}
  local max_money = max_moneys[variant]

  if max_money > game:get_max_money() then
    game:set_max_money(max_money)
  else
    if game:get_max_money() == 500 then
      item:set_variant(2)
    else
      item:set_variant(3)
    end

    game:start_dialog("_treasure.rupee_bag.already_own_bigger_rupee_bag")
    
  end
end
