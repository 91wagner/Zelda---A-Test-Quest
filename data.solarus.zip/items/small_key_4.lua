local item = ...
local game = item:get_game()



function item:on_created()
  item:set_savegame_variable("possession_small_key_4")
  item:set_brandish_when_picked(false)
  item:set_sound_when_brandished("picked_small_key")
  item:set_shadow("small")
  item:set_sound_when_picked("picked_small_key")

  item:set_amount_savegame_variable("amount_small_key_4")
  item:set_max_amount(99)

end 

function item:on_obtained(variant, savegame_variable)  
  item:add_amount(1)
end