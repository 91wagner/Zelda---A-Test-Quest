local item = ... 

function item:on_created()
  self:set_savegame_variable("possession_pegasus_shoes")
end

function item:on_obtaining()
  self:get_game():set_ability("run", 1)
end
