local item = ...
local game = item:get_game()

function item:on_created()
  item:set_savegame_variable("possession_lamp")
  item:set_assignable(true)

end


function item:on_using()

  item:create_fire()
  sol.audio.play_sound("lamp")
  item:set_finished()
end


function item:create_fire()

  local hero = item:get_map():get_entity("hero")
  local x, y, layer = hero:get_position()
  local direction = hero:get_direction()
  if direction == 0 then
    x = x + 16
  elseif direction == 1 then
    y = y - 16
  elseif direction == 2 then
    x = x - 16
  elseif direction == 3 then
    y = y + 16
  end

  item:get_map():create_fire{
    x = x,
    y = y,
    layer = layer
  }
end