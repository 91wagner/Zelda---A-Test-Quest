local item = ...
local game = item:get_game()

function item:on_created()
  item:set_savegame_variable("possession_tunic")
  
end


function item:on_obtained(variant, savegame_variable)
  tunic_variant = game:get_ability("tunic")
  if tunic_variant < variant then
    game:set_ability("tunic", variant)
  elseif tunic_variant == variant then
    game:start_dialog("item_already_obtained")
  else 
    game:start_dialog("better_variant")
  end

end
