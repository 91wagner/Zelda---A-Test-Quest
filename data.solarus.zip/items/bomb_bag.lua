local item = ...
local game = item:get_game()

function item:on_created()
  item:set_savegame_variable("possession_bomb_bag")
end

function item:on_started()
  item:on_variant_changed(item:get_variant())
end

function item:on_variant_changed(variant)
  local bomb_counter = game:get_item("bomb_counter")
  local bomb = game:get_item("bomb")
  if variant == 0 then
    bomb_counter:set_max_amount(0)
    bomb:set_obtainable(false)
  else
    local max_amounts = {15, 30, 45}
    local max_amount = max_amounts[variant]

    bomb_counter:set_variant(1)
    bomb_counter:set_max_amount(max_amount)

    bomb:set_obtainable(true)
  end
end 

function item:on_obtained(variant, savegame_variable)
  if variant > 0 then
   local bomb_counter = game:get_item("bomb_counter")
   bomb_counter:set_amount(bomb_counter:get_max_amount())
  end
end