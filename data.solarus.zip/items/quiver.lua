local item = ...
local game = item:get_game()
local bow = game:get_item("bow")

local function update_quiver()
  local variant = item:get_variant()
  local bow = game:get_item("bow")
  local arrow = game:get_item("arrow")
  if variant == 0 then
    bow:set_max_amount(0)
    arrow:set_obtainable(false)
  else
    local amounts = {30, 60, 99}
    bow:set_max_amount(amounts[variant])
    arrow:set_obtainable(true)
  end
end



function item:on_created()
  item:set_savegame_variable("possession_quiver")

end

function item:on_started()
  update_quiver()
end

function item:on_variant_changed(variant)
  update_quiver()
end

function item:on_obtaining(variant, savegame_variable)
  if variant > 0 then
    local bow = game:get_item("bow")
    bow:set_amount(bow:get_max_amount())
  end
end