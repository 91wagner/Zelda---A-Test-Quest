-- This is the main Lua script of your project.

-- You will probably make a title screen and then start a game.

-- See the Lua API! http://www.solarus-games.org/solarus/documentation/


-- This is just an example of quest that shows the Solarus logo

-- and then does nothing.
-- Feel free to change this!


local game_manager = require("scripts/game_manager")
local console = require("scripts/console")
local debug_menu = require("scripts/debug")

local game


-- Startet das Spiel game, welches als Parameter uebergeben wurde
function sol.main.start_game(game)
  sol.main.game = game
  game:start()
end

function sol.main:on_started()


  -- This function is called when Solarus starts.
  -- Erlaubt Cheaten
  sol.menu.start(self, debug_menu)


  -- Setting a language is useful to display text and dialogs.

  sol.language.set_language("de")



  local solarus_logo = require("menus/solarus_logo")
  local title_screen = require("menus/title_screen")
  local savegames_menu = require("scripts/menus/savegames")


  -- Show the Solarus logo initially.
  sol.main.load_settings("settings.dat")
  sol.menu.start(self, solarus_logo)

  function solarus_logo.on_finished()
    sol.menu.start(self, title_screen)
  end

  function title_screen.on_finished()
    sol.menu.start(sol.main, savegames_menu)
  end

  function savegames_menu.on_finished()
    sol.audio.preload_sounds()
  end
end

