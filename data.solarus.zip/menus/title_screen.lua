local menu = {}

local text = sol.text_surface.create({
  font = "alttp",
  horizontal_alignment = "center",
  font_size = 14,
  text = "- Leertaste druecken -",
})

local logo = sol.sprite.create("menus/zelda_logo")

local function stop()
  sol.audio.play_sound("danger")
  sol.menu.stop(menu) 
end 


function menu:on_started()

  sol.audio.play_music("title_screen")
end


function menu:on_key_pressed(key)
  if key == "space" then
    stop()
  end
end


function menu:on_draw(dst_surface)
  dst_surface:fill_color({20,160,80})
  logo:draw(dst_surface, 20,0)
  text:draw(dst_surface, 180, 200)
end

return menu