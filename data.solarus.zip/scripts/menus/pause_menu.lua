local pause_manager = {}

function pause_manager:create(game)
  local pause_menu = {}


  local cursor_row = 0
  local cursor_column = 0
  local hero_x = 0
  local hero_y = 0

  local on_map = false


  function pause_menu:on_started()

    on_map = false
    sol.audio.play_sound("pause_open")
    pause_menu:rebuild_surface()
    pause_menu:rebuild_cursor_surface()
    pause_menu:rebuild_map()
  end



  function pause_menu:initialize()

    pause_menu.unchanged_surface = sol.surface.create(320,240)
    pause_menu.surface = sol.surface.create(320,240)
    pause_menu.cursor_surface = sol.surface.create(320,240)

    pause_menu.screen = sol.surface.create("menus/pause_menu.png")
    pause_menu.text_weapons = sol.text_surface.create({
      text = sol.language.get_string("pause_menu.weapons"),
      font = "8_bit",
    })
    pause_menu.text_save_quit = sol.text_surface.create({
      text = sol.language.get_string("pause_menu.save_quit"),
      font = "8_bit",
    })
    pause_menu.text_heart_pieces = sol.text_surface.create({
      font = "8_bit",
    })


    -- Menue-Hintergrund zeichnen
    pause_menu.screen:draw(pause_menu.unchanged_surface)

    -- Menue-Bildschirm Texte
    pause_menu.text_weapons:draw(pause_menu.unchanged_surface, 24, 70)
    pause_menu.text_save_quit:draw(pause_menu.unchanged_surface, 44, 145)

    -- Herzteil in Ecke unten rechts
    local piece_of_heart = sol.surface.create("items/piece_of_heart.png")
    piece_of_heart:draw(pause_menu.unchanged_surface, 256, 167)   

    -- Item-Slots setzen
    local pause_menu_item_slot = sol.surface.create("menus/pause_menu_item_slot.png")
    
    for i = 0, 3 do
      pause_menu_item_slot:draw(pause_menu.unchanged_surface, 35 + i * 54, 88)
    end
    for i = 0, 2 do
      pause_menu_item_slot:draw(pause_menu.unchanged_surface, 263, 67 + i * 28)
    end
    for i = 0, 6 do
      pause_menu_item_slot:draw(pause_menu.unchanged_surface, 23 + i * 31, 162)
    end

    -- Cursor erstelen
    pause_menu.cursor = sol.surface.create("menus/pause_menu_cursor.png")
    pause_menu.cursor_fairy = sol.surface.create("menus/fairy_cursor.png")

    -- Item Icons bereitstellen
    pause_menu.lamp_icon = sol.surface.create("items/lamp_1.png")
    pause_menu.bomb_icon = sol.surface.create("items/bomb_counter_1.png")
    pause_menu.bow_icon_empty = sol.surface.create("items/bow_1.png")
    pause_menu.bow_icon = sol.surface.create("items/bow_2.png")
    pause_menu.pegasus_icon = sol.surface.create("items/pegasus_shoes.png")
    pause_menu.flippers_icon = sol.surface.create("items/flippers.png")
    pause_menu.bottle_icon = sol.surface.create("items/bottle_fairy.png")
    pause_menu.bottle_icon_empty = sol.surface.create("items/empty_bottle.png")
    pause_menu.fire_stone_icon = sol.surface.create("items/fire_stone.png")

    pause_menu.boomerang_icon = nil
    pause_menu.sword_icon = nil
    pause_menu.shield_icon = nil
    pause_menu.tunic_icon = nil
    pause_menu.glove_icon = nil
    pause_menu.rupee_bag_icon = nil
    pause_menu.bomb_bag_icon = nil
    pause_menu.quiver_icon = nil


    -- World Map und Helden Sprite laden
    pause_menu.world_map = sol.surface.create("menus/world_map.png")
    pause_menu.hero_head = sol.sprite.create("menus/hero_head")
  end


  function pause_menu:rebuild_surface()

    pause_menu.surface:clear()

    pause_menu.text_heart_pieces:set_text(game:get_value("nb_piece_of_heart") .. "/4")
    pause_menu.text_heart_pieces:draw(pause_menu.surface, 272, 175)

    

    -- Lampe darstellen
    if game:has_item("lamp") then
      pause_menu.lamp_icon:draw(pause_menu.surface, 41, 94)
    end

    -- Bummerang dartstellen
    if game:has_item("boomerang") then
      pause_menu.boomerang_icon = sol.surface.create("items/boomerang_" .. game:get_item("boomerang"):get_variant() .. ".png")
      pause_menu.boomerang_icon:draw(pause_menu.surface, 95, 94)
    end

    -- Bombe darstellen
    if game:has_item("bomb_bag") then
      pause_menu.bomb_icon:draw(pause_menu.surface, 149, 94)
    end

    -- Bogen darstellen
    if game:has_item("bow") then
      if game:get_item("bow"):get_amount() == 0 then
        pause_menu.bow_icon_empty:draw(pause_menu.surface, 203, 94)
      else
        pause_menu.bow_icon:draw(pause_menu.surface, 203, 94)
      end
    end

    -- Schwert darstellen

    if game:has_item("sword") then
      pause_menu.sword_icon = sol.surface.create("items/sword_" .. game:get_item("sword"):get_variant() .. ".png")
      pause_menu.sword_icon:draw(pause_menu.surface, 269, 73)
    end
  
    -- Schild darstellen
    if game:has_item("shield") then
      pause_menu.shield_icon = sol.surface.create("items/shield_" .. game:get_item("shield"):get_variant() .. ".png")
      pause_menu.shield_icon:draw(pause_menu.surface, 269, 101)
    end

    -- Ruestung darstellen
    pause_menu.tunic_icon = sol.surface.create("items/tunic_" .. game:get_ability("tunic") .. ".png")
    pause_menu.tunic_icon:draw(pause_menu.surface, 269, 129)
    

    -- Pegasus-Stiefel darstellen
    if game:has_item("pegasus_shoes") then
      pause_menu.pegasus_icon:draw(pause_menu.surface, 29, 168)
    end

    -- Handschuh darstellen
    if game:has_item("glove") then
      pause_menu.glove_icon = sol.surface.create("items/glove_" .. game:get_item("glove"):get_variant() .. ".png")
      pause_menu.glove_icon:draw(pause_menu.surface, 60, 168)
    end

    -- Flossen darstellen
    if game:has_item("flippers") then
      pause_menu.flippers_icon:draw(pause_menu.surface, 91, 168)
    end

    -- Geldboerse darstellen
    if game:has_item("rupee_bag") then
      pause_menu.rupee_bag_icon = sol.surface.create("items/rupee_bag_" .. game:get_item("rupee_bag"):get_variant() .. ".png")
      pause_menu.rupee_bag_icon:draw(pause_menu.surface, 122, 168)
    end

    -- Bombentasche darstellen
    if game:has_item("bomb_bag") then
      pause_menu.bomb_bag_icon = sol.surface.create("items/bomb_bag_" .. game:get_item("bomb_bag"):get_variant() .. ".png")
      pause_menu.bomb_bag_icon:draw(pause_menu.surface, 153, 168)
    end

    -- Koecher darstellen
    if game:has_item("quiver") then
      pause_menu.quiver_icon = sol.surface.create("items/quiver_" .. game:get_item("quiver"):get_variant() .. ".png")
      pause_menu.quiver_icon:draw(pause_menu.surface, 184, 168)
    end

    -- Flasche darstellen
    if game:has_item("empty_bottle") then
      if game:get_value("fairy_possessed") then
        pause_menu.bottle_icon:draw(pause_menu.surface, 215, 168)
      else
        pause_menu.bottle_icon_empty:draw(pause_menu.surface, 215, 168)
      end
    end

    -- Feuerstein darstellen
    if game:has_item("fire_stone") then
      pause_menu.fire_stone_icon:draw(pause_menu.surface, 215, 168)
    end

  end

  

  function pause_menu:rebuild_cursor_surface()

    pause_menu.cursor_surface:clear()
    -- Cursor setzen
    if cursor_row == 0 then
      pause_menu.cursor:draw(pause_menu.cursor_surface, 24 + cursor_column * 54, 77)
    else 
      pause_menu.cursor_fairy:draw(pause_menu.cursor_surface, 24 + (120 * math.floor(cursor_column / 2)), 138)
    end

  end

  
  function pause_menu:rebuild_map()

    pause_menu.hero_head:set_animation("tunic" .. game:get_ability("tunic"))
    local map = game:get_map()
    local world = map:get_world()
    local id = map:get_id()
    
    if world == "Dungeon_1" then
      hero_x = 111
      hero_y = 75
   
    elseif world == "Dungeon_2" then
      hero_x = 242
      hero_y = 160

    elseif world == "Dungeon_3" or world == "Desert" then
      hero_x = 108
      hero_y = 196

    elseif world == "Dungeon_4" then
      hero_x = 239
      hero_y = 83
    
    elseif world == "Bibliothek" then
      hero_x = 56
      hero_y = 58

    elseif world == "Sahasrahla" then
      hero_x = 152
      hero_y = 92

    elseif world == "Shop" then
      hero_x = 180
      hero_y = 76

    elseif world == "woods" then
      hero_x = 178
      hero_y = 57

    elseif world == "Final_Cave" then
      hero_x = 146
      hero_y = 118
    
    elseif world == "Oberwelt" then
      if id == "Spiel1/houses/red_house" then
        hero_x = 157
        hero_y = 64
      
      elseif id == "Spiel1/houses/green_house" then
        hero_x = 138
        hero_y = 93

      elseif id == "Spiel1/houses/blacksmith" or id == "Spiel1/overworld_7_6" or id == "Spiel1/caves/under_the_tree" then
        hero_x = 197
        hero_y = 196
  
      elseif id == "Spiel1/caves/behind_castle" then
        hero_x = 256
        hero_y = 58

      elseif id == "Spiel1/caves/cave_1" then
        hero_x = 42
        hero_y = 56

      elseif id == "Spiel1/caves/cave_2" then
        hero_x = 106
        hero_y = 55

      elseif id == "Spiel1/caves/cave_in_front_of_desert" then
        hero_x = 156
        hero_y = 192

      elseif id == "Spiel1/caves/hole_under_hotel" then
        hero_x = 157
        hero_y = 64

      else
        local map_x, map_y = map:get_location()
        local h_x, h_y = map:get_hero():get_position()
        hero_x = 32 + (map_x + h_x)/10
        hero_y = 55 + (map_y + h_y)/10
      end
    else
      hero_x = -20
      hero_y = -20
    end
  end


  function pause_menu:on_draw(dst_surface)

    if not on_map then
      pause_menu.unchanged_surface:draw(dst_surface, 0, 0)
      pause_menu.surface:draw(dst_surface, 0, 0)
      pause_menu.cursor_surface:draw(dst_surface, 0,0)
    else
      pause_menu.world_map:draw(dst_surface, 0, 0)
      pause_menu.hero_head:draw(dst_surface, hero_x, hero_y)
    end
  end





  function pause_menu:on_command_pressed(command)

    if not on_map then
     
    if game:is_dialog_enabled() then
      return false
    end
    

    local lamp = game:get_item("lamp")
    local boomerang = game:get_item("boomerang")
    local bomb = game:get_item("bomb_counter")
    local bow = game:get_item("bow")

    if command == "right" then
      sol.audio.play_sound("cursor")
      if cursor_row == 0 then
        cursor_column = (cursor_column + 1) % 4
      else
        cursor_column = (cursor_column + 2) % 4
      end

    elseif command == "left" then
      sol.audio.play_sound("cursor")
      if cursor_row == 0 then
        cursor_column = (cursor_column + 3) % 4
      else
        cursor_column = (cursor_column + 2) % 4
      end

    elseif command == "down" then
      sol.audio.play_sound("cursor")
      cursor_row = (cursor_row + 1) % 2

    elseif command == "up" then
      sol.audio.play_sound("cursor")
      cursor_row = (cursor_row + 1) % 2



    elseif command == "action" then
      if cursor_row == 1 then
        if math.floor(cursor_column / 2) == 0 then
          game:save()
          sol.audio.play_sound("danger")
        else
          game:start_dialog("end_game_question", function(answer)
            if answer == 2 or answer == 3 then
              if answer == 3 then
                game:save()
                sol.audio.play_sound("danger")
              end
              sol.main.reset()
            end
          end)
        end
      else
        if cursor_column == 0 and game:has_item("lamp") then
          game:start_dialog("pause_menu.lamp")
        elseif cursor_column == 1 and game:has_item("boomerang") then
          game:start_dialog("pause_menu.boomerang")
        elseif cursor_column == 2 and game:has_item("bomb_bag") then
          game:start_dialog("pause_menu.bomb")
        elseif cursor_column == 3 and game:has_item("bow") then
          game:start_dialog("pause_menu.bow")
        end       
      end



    elseif command == "item_1" then

      if cursor_row == 0 then
        if cursor_column == 0 and game:has_item("lamp") then
          if game:get_item_assigned(2) == lamp then
            game:set_item_assigned(2, game:get_item_assigned(1))
          end
          game:set_item_assigned(1, lamp)
          sol.audio.play_sound("throw")

        elseif cursor_column == 1 and game:has_item("boomerang") then
          if game:get_item_assigned(2) == boomerang then
            game:set_item_assigned(2, game:get_item_assigned(1))
          end
          game:set_item_assigned(1, boomerang)
          sol.audio.play_sound("throw")

        elseif cursor_column == 2 and game:has_item("bomb_counter") then
          if game:get_item_assigned(2) == bomb then
            game:set_item_assigned(2, game:get_item_assigned(1))
          end
          game:set_item_assigned(1, bomb)
          sol.audio.play_sound("throw")

        elseif cursor_column == 3 and game:has_item("bow") then
          if game:get_item_assigned(2) == bow then
            game:set_item_assigned(2, game:get_item_assigned(1))
          end
          game:set_item_assigned(1, bow)
          sol.audio.play_sound("throw")
        end
      end

    elseif command == "item_2" then
       if cursor_row == 0 then
        if cursor_column == 0 and game:has_item("lamp") then
          if game:get_item_assigned(1) == lamp then
            game:set_item_assigned(1, game:get_item_assigned(2))
          end
          game:set_item_assigned(2, lamp)
          sol.audio.play_sound("throw")

        elseif cursor_column == 1 and game:has_item("boomerang") then
          if game:get_item_assigned(1) == boomerang then
            game:set_item_assigned(1, game:get_item_assigned(2))
          end
          game:set_item_assigned(2, boomerang)
          sol.audio.play_sound("throw")

        elseif cursor_column == 2 and game:has_item("bomb_counter") then
          if game:get_item_assigned(1) == bomb then
            game:set_item_assigned(1, game:get_item_assigned(2))
          end
          game:set_item_assigned(2, bomb)
          sol.audio.play_sound("throw")

        elseif cursor_column == 3 and game:has_item("bow") then
          if game:get_item_assigned(1) == bow then
            game:set_item_assigned(1, game:get_item_assigned(2))
          end
          game:set_item_assigned(2, bow)
          sol.audio.play_sound("throw")
        end
      end

    end

    lamp = nil
    boomerang = nil
    bomb = nil
    bow = nil

    pause_menu:rebuild_cursor_surface()
  end
  end

  function pause_menu:on_key_pressed(key, modifier)

  
    if key == "f" then
      on_map = not on_map
      sol.audio.play_sound("pause_open")
    end
  end

  function pause_menu:on_finished()
    sol.audio.play_sound("pause_closed")

  end

  pause_menu:initialize()

  return pause_menu

end

return pause_manager