local prob_easy = {}

prob_easy.rupee_1  = 180
prob_easy.rupee_5  = 60
prob_easy.rupee_20 =  50
prob_easy.heart    = 350
prob_easy.fairy    =  10
prob_easy.bomb     =  70
prob_easy.arrow_1    =  20
prob_easy.arrow_5  =  70
prob_easy.arrow_10 = 20

prob_easy.sum = {prob_easy.rupee_1, prob_easy.rupee_1+prob_easy.rupee_5, prob_easy.rupee_1+prob_easy.rupee_5+prob_easy.rupee_20, prob_easy.rupee_1+prob_easy.rupee_5+prob_easy.rupee_20+prob_easy.heart, prob_easy.rupee_1+prob_easy.rupee_5+prob_easy.rupee_20+prob_easy.heart+prob_easy.fairy, prob_easy.rupee_1+prob_easy.rupee_5+prob_easy.rupee_20+prob_easy.heart+prob_easy.fairy+prob_easy.bomb, prob_easy.rupee_1+prob_easy.rupee_5+prob_easy.rupee_20+prob_easy.heart+prob_easy.fairy+prob_easy.bomb+prob_easy.arrow_1, prob_easy.rupee_1+prob_easy.rupee_5+prob_easy.rupee_20+prob_easy.heart+prob_easy.fairy+prob_easy.bomb+prob_easy.arrow_1+prob_easy.arrow_5, prob_easy.rupee_1+prob_easy.rupee_5+prob_easy.rupee_20+prob_easy.heart+prob_easy.fairy+prob_easy.bomb+prob_easy.arrow_1+prob_easy.arrow_5+prob_easy.arrow_10}

prob_easy.treasure = {"rupee", "rupee", "rupee", "heart", "fairy", "bomb", "arrow", "arrow", "arrow"}
prob_easy.variant = {1, 2, 3, 1, 1, 1, 1, 2, 3}

return prob_easy
