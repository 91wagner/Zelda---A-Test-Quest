local savegames_menu = {}

local game_manager = require("scripts/game_manager")
local gui_designer = require("scripts/menus/gui_designer")
local hearts_builder = require("scripts/hud/hearts")

local cursor_img = sol.surface.create("menus/link_cursor.png")
local cursor_position
local fairy_cursor_img = sol.surface.create("menus/fairy_cursor.png")
local fairy_cursor_position
local savegames_surfaces = {}
local games = {}

local layout 

local delete_mode = false


local function build_layout()

  layout = gui_designer:create(320, 240)
  layout:make_background()
  layout:make_big_wooden_frame(16, 8, 200, 32)
  if not delete_mode then
    layout:make_text(sol.language.get_string("savegames_menu.title"), 116, 16, "center")
  else
    layout:make_text(sol.language.get_string("savegames_menu.really_delete"), 116, 16, "center")
  end

  layout:make_wooden_frame(16, 48, 288, 36)
  layout:make_wooden_frame(16, 96, 288, 36)
  layout:make_wooden_frame(16, 144, 288, 36)

  layout:make_big_wooden_frame(16, 200, 288, 32)
  if not delete_mode then
    layout:make_text(sol.language.get_string("savegames_menu.start"), 56, 208, "left")
    layout:make_text(sol.language.get_string("savegames_menu.delete"), 176, 208, "left")
  else
    layout:make_text(sol.language.get_string("savegames_menu.yes"), 56, 208, "left")
    layout:make_text(sol.language.get_string("savegames_menu.no"), 176, 208, "left")
  end
end

local function set_cursor_position(index)

  cursor_position = index
  cursor_img:set_xy(26, 5 + index * 48)
end


local function set_fairy_cursor_position(index)
  
  fairy_cursor_position = index
  fairy_cursor_img:set_xy(36 + index * 120, 208)
end


local function get_savegame_file_name(index)

  return "save" .. index .. ".dat"
end


local function draw_hearts(game, surface)
  
  local hearts = hearts_builder:new(game)
  hearts:rebuild_surface()
  hearts.surface:draw(surface)
end


local function draw_sword(game, surface)
  
  local nb_hearts_per_row = game:get_value("nb_hearts_per_row")
  local image_sword 
  local sword_item
  if game:has_item("sword") then
    sword_item = game:get_item("sword")
    image_sword = sol.surface.create("items/sword_" .. sword_item:get_variant() .. ".png")
    image_sword:draw(surface, 10 * nb_hearts_per_row + 4, 2)
  end
end 

local function draw_shop_man(game, surface)
  
  local nb_hearts_per_row = game:get_value("nb_hearts_per_row")
  local image_shop_man
  if game:get_value("dungeon_2_finished") then
    image_shop_man = sol.surface.create("npc/shop_man.png")
    image_shop_man:draw(surface, 10 * nb_hearts_per_row + 4 + 16 + 4, -1)
  end
end 


local function draw_sahasrahla(game, surface)
  
  local nb_hearts_per_row = game:get_value("nb_hearts_per_row")
  local image_sahasrahla
  if game:get_value("dungeon_1_finished") then
    image_sahasrahla = sol.surface.create("npc/sahasrahla.png")
    image_sahasrahla:draw(surface, 10 * nb_hearts_per_row + 4 + 16 + 4 + 16 + 4, -1)
  end
end 


local function draw_amulet(game, surface)

  local nb_hearts_per_row = game:get_value("nb_hearts_per_row")
  local image_amulet
  if game:has_item("amulet_of_courage") then
    image_amulet = sol.surface.create("entities/amulet_of_courage.png")
    image_amulet:draw(surface, 10 * nb_hearts_per_row + 4 + 16 + 4 + 16 + 4 + 16 + 4, 3)
  end
end


local function draw_triforce(game, surface)

  local nb_hearts_per_row = game:get_value("nb_hearts_per_row")
  local triforce_image
  if game:get_value("ganon_defeated") then
    triforce_image = sol.surface.create("entities/triforce.png")
    triforce_image:draw(surface, 10 * nb_hearts_per_row + 4 + 16 + 4 + 16 + 4 + 16 + 4 + 16 + 4, 0)
  end
end


local function draw_nb_deaths(game, surface)

  local nb_death = game:get_value("nb_deaths")

  local nb_deaths_text100 = sol.text_surface.create()
  nb_deaths_text100:set_text((nb_death - (nb_death % 100)) / 100)
  nb_deaths_text100:set_font("white_digits")

  local nb_deaths_text10 = sol.text_surface.create()
  nb_deaths_text10:set_text(((nb_death % 100) - (nb_death % 10))/10)
  nb_deaths_text10:set_font("white_digits")

  local nb_deaths_text1 = sol.text_surface.create()
  nb_deaths_text1:set_text(nb_death % 10)
  nb_deaths_text1:set_font("white_digits")

  local nb_deaths_text = sol.text_surface.create()
  nb_deaths_text:set_text("Tode:")

  nb_deaths_text:draw(surface, 175, 15)
  nb_deaths_text100:draw(surface, 220, 16)
  nb_deaths_text10:draw(surface, 230, 16)
  nb_deaths_text1:draw(surface, 240, 16)
end


local function draw_time(game, surface)

  local time = game:get_value("play_time")
  local min = time % 60
  local hours = (time - min ) / 60


  local hours10 = sol.text_surface.create()
  hours10:set_text((hours - (hours % 10)) / 10)
  local hours1 = sol.text_surface.create()
  hours1:set_text(hours % 10)
  local min10 = sol.text_surface.create()
  min10:set_text((min - min % 10) / 10)
  local min1 = sol.text_surface.create()
  min1:set_text(min % 10)
  local dp = sol.text_surface.create()
  dp:set_text(":")
  
  hours10:draw(surface, 200, 3)
  hours1:draw(surface, 210, 3)
  dp:draw(surface, 220, 3)
  min10:draw(surface, 230, 3)
  min1:draw(surface, 240, 3)
end


local function read_savegames()
  
  for i = 1, 3 do
    local file_name = get_savegame_file_name(i)
    local surface = sol.surface.create(272, 20)
    surface:set_xy(48, 8 + i * 48)
    savegames_surfaces[i] = surface

    if not sol.game.exists(file_name) then
      games[i] = nil
    else
      local game = game_manager:create(file_name)
      games[i] = game

      draw_hearts(game, surface)
      draw_sword(game, surface)
      draw_shop_man(game, surface)
      draw_sahasrahla(game, surface)
      draw_amulet(game, surface)
      draw_triforce(game, surface)
      draw_nb_deaths(game, surface)
      draw_time(game, surface)
    end
  end
end



function savegames_menu:on_started()

  build_layout()
  read_savegames()
  sol.audio.play_music("game_over")
  set_cursor_position(1)
  set_fairy_cursor_position(0)
end



function savegames_menu:on_draw(dst_surface)

  layout:draw(dst_surface)

  for i = 1, 3 do
    savegames_surfaces[i]:draw(dst_surface)
  end

  cursor_img:draw(dst_surface)
  fairy_cursor_img:draw(dst_surface)
end


function savegames_menu:on_key_pressed(key)

  local handled = false

  if key == "space" and not delete_mode then
    local file_name = get_savegame_file_name(cursor_position)

    if fairy_cursor_position == 0 then
      sol.audio.play_sound("ok")
      sol.main.start_game(game_manager:create(file_name))
      sol.menu.stop(savegames_menu)
      handled = true
    
    else
      if sol.game.exists(file_name) then
        sol.audio.play_sound("boss_hurt")
        delete_mode = true
        build_layout()
        handled = true
      else
        sol.audio.play_sound("bounce")
        handled = true
      end
    end

  elseif key == "space" and delete_mode then
    local file_name = get_savegame_file_name(cursor_position)

    if fairy_cursor_position == 1 then
      delete_mode = false
      build_layout()
      sol.audio.play_sound("cursor")
      handled = true
    
    else
      sol.game.delete(file_name)
      read_savegames()
      delete_mode = false
      build_layout()
      sol.audio.play_sound("boss_killed")
      handled = true
    end
      

  elseif key == "down" and not delete_mode then
    if cursor_position < 3 then
      set_cursor_position(cursor_position + 1)
    else
      set_cursor_position(1)
    end
    sol.audio.play_sound("cursor")
    handled = true
 
  elseif key == "up" and not delete_mode then
    if cursor_position > 1 then
      set_cursor_position(cursor_position - 1)
    else
      set_cursor_position(3)
    end
    sol.audio.play_sound("cursor")
    handled = true

  elseif key == "right" then
    set_fairy_cursor_position((fairy_cursor_position + 1) % 2)
    sol.audio.play_sound("cursor")
    handled = true

  elseif key == "left" then
    set_fairy_cursor_position((fairy_cursor_position + 1) % 2)
    sol.audio.play_sound("cursor")
    handled = true
  end

  return handled
end



return savegames_menu

