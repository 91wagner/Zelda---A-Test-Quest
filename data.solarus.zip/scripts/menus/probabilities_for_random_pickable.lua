local prob = {}

prob.rupee_1  = 180
prob.rupee_5  = 60
prob.rupee_20 =  20
prob.heart    = 150
prob.fairy    =  5
prob.bomb     =  60
prob.arrow_1    =  20
prob.arrow_5  =  50
prob.arrow_10 = 10

prob.sum = {prob.rupee_1, prob.rupee_1+prob.rupee_5, prob.rupee_1+prob.rupee_5+prob.rupee_20, prob.rupee_1+prob.rupee_5+prob.rupee_20+prob.heart, prob.rupee_1+prob.rupee_5+prob.rupee_20+prob.heart+prob.fairy, prob.rupee_1+prob.rupee_5+prob.rupee_20+prob.heart+prob.fairy+prob.bomb, prob.rupee_1+prob.rupee_5+prob.rupee_20+prob.heart+prob.fairy+prob.bomb+prob.arrow_1, prob.rupee_1+prob.rupee_5+prob.rupee_20+prob.heart+prob.fairy+prob.bomb+prob.arrow_1+prob.arrow_5, prob.rupee_1+prob.rupee_5+prob.rupee_20+prob.heart+prob.fairy+prob.bomb+prob.arrow_1+prob.arrow_5+prob.arrow_10}

prob.treasure = {"rupee", "rupee", "rupee", "heart", "fairy", "bomb", "arrow", "arrow", "arrow"}
prob.variant = {1, 2, 3, 1, 1, 1, 1, 2, 3}

return prob