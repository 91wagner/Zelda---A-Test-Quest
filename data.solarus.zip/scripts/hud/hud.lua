local hud_manager = {}







function hud_manager:create(game)
  local hud = {}

  function hud:on_started()

-- Anzahl der Herzen pro Zeile
    local nb_columns_hearts = 8
    game:set_value("nb_hearts_per_row", nb_columns_hearts)

    hud_complete_surface = hud:build_surface()
  end


  local function hud:build_surface()
    local hud_surface = sol.surface.create(320, 240)
    rupees_create():draw(hud_surface, 0, 0)
    bombs_create():draw(hud_surface, 0, 0)
    arrows_create():draw(hud_surface, 0, 0)
    hearts_create():draw(hud_surface, 0, 0)
    items_create():draw(hud_surface, 0, 0)

    return hud_surface
  end 



  local hud:on_draw(dst_surface)
    hud_complete_surface:draw(dst_surface, 0, 0)
  end





-- Anzahl Rubine unten links darstellen

  local function rupees_create()
    local dst_surface = sol.surface.create(320, 240)
    local rupee_icon = sol.surface.create("hud/rupee_icon.png")
    local rupee_text = sol.text_surface.create()
   
    
    if game:has_item("rupee_bag") then
      local rupee_bag_variant = game:get_item("rupee_bag"):get_variant()
      if rupee_bag_variant ~= 0 then
        rupee_icon:draw_region(12 * (rupee_bag_variant - 1), 0, 12, 12, dst_surface, 10, 225)
      end
    end

    rupee_text:set_text(game:get_money())

    -- Farb-Aenderung bei maximalem Geld.
    if game:get_money() == game:get_max_money() then
      rupee_text:set_font("green_digits")
    else
      rupee_text:set_font("white_digits")
    end

    rupee_text:draw(dst_surface, 25, 230)
    return dst_surface
  end




--  Anzahl Bomben unten links darstellen
  local function bombs_create()
    local dst_surface = sol.surface.create(320, 240)
    local small_bomb_icon = sol.surface.create("menus/bomb_icon.png")
    local bomb_text = sol.text_surface.create()
    
    
    if game:has_item("bomb_bag") then
      bomb_text:set_text(game:get_item("bomb_bag"):get_amount())
      if game:get_item("bomb_bag"):get_amount() == game:get_item("bomb_bag"):get_max_amount() then
        bomb_text:set_font("green_digits")
      else
        bomb_text:set_font("white_digits")
      end
      small_bomb_icon:draw(dst_surface, 15, 213)
      bomb_text:draw(dst_surface, 25, 217)
    end
    return dst_surface
  end




--  Anzahl Pfeile unten links darstellen
  local function arrows_create()
    local dst_surface = sol.surface.create(320, 240)
    local small_arrow_icon = sol.surface.create("menus/arrow_icon.png")
    local bow_text = sol.text_surface.create()
   
    if game:has_item("bow") then
      bow_text:set_text(game:get_item("bow"):get_amount())
      if game:get_item("bow"):get_amount() == game:get_item("bow"):get_max_amount() then
        bow_text:set_font("green_digits")
      else
        bow_text:set_font("white_digits")
      end
      small_arrow_icon:draw(dst_surface, 16, 201)
      bow_text:draw(dst_surface, 25, 205)
    end
    return dst_surface
  end




  
-- fuer den Warnton bei niedriger Energie
  local danger_sound_repeat = false
  
  function game:on_map_changed()
    danger_sound_repeat = false
  end

  function danger_sound()
    if danger_sound_repeat then
      sol.timer.start(math.floor(math.sqrt(game:get_life() / math.sqrt( game:get_max_life())) * 900) , function()
        sol.audio.play_sound("danger")
        danger_sound()
      end)
    end
  end



--Hier wird die Herzanzeige erstellt
  local function create_hearts()
    local dst_surface = sol.surface.create(320, 240)
--  Anzeige erscheint oben rechts, wenn Held in obere linke Ecke laeuft
    local hero_x, hero_y = game:get_hero():get_position()
    local switch_right_hearts = 0 
    if hero_x < 50 + 10 * nb_columns_hearts and hero_y < 140  then
      switch_right_hearts = 310 - 10 * nb_columns_hearts
    end



-- Herzanzeige oben links (rechts) darstellen
    local hearts_icon = sol.surface.create("hud/hearts.png")
    local max_life = game:get_max_life()
    local current_life = game:get_life()
    local full_hearts = math.floor(current_life / 4)
    local rest_hearts = current_life % 4
    --leere Herzen
    for i = 1, max_life / 4 do
      if i <= nb_columns_hearts then
        hearts_icon:draw_region(0, 9, 9, 9, dst_surface, switch_right_hearts - 5 + i * 10, 5)
      else
        hearts_icon:draw_region(0, 9, 9, 9, dst_surface, switch_right_hearts - 5 + (i - nb_columns_hearts) * 10, 15)
      end  
    end
    -- volle Herzen
    for i = 1, math.floor(current_life / 4) do
      if i <= nb_columns_hearts then
        hearts_icon:draw_region(27, 0, 9, 9, dst_surface, switch_right_hearts - 5 + i*10, 5)
      else
        hearts_icon:draw_region(27, 0, 9, 9, dst_surface, switch_right_hearts - 5 + (i - nb_columns_hearts)*10, 15)
      end
    end
    -- Teilherz
    if rest_hearts ~= 0 then
      if full_hearts < nb_columns_hearts then
        hearts_icon:draw_region(9 * (rest_hearts - 1), 0, 9, 9, dst_surface, switch_right_hearts - 5 + 10 * (full_hearts + 1), 5)
      else
        hearts_icon:draw_region(9 * (rest_hearts - 1), 0, 9, 9, dst_surface, switch_right_hearts - 5 + 10 * (full_hearts + 1 - nb_columns_hearts), 15)
      end
    end


    -- Warnton bei niedriger Energie
    if current_life <= max_life / 4 and current_life ~= 0 then
      if not danger_sound_repeat then
        danger_sound_repeat = true
        danger_sound()
      end
    else
      danger_sound_repeat = false
    end
    return dst_surface
  end





-- Item-Slots oben links (rechts) anzeigen 
  local function create_items() 
    local dst_surface = sol.surface.create(320, 240)
    local slot_icon = sol.surface.create("hud/item_slot.png")
    -- Slots zeichnen
    slot_icon:draw_region(0, 0, 24, 24, dst_surface, 5 + switch_right_hearts, 26)
    slot_icon:draw_region(0, 0, 24, 24, dst_surface, 32 + switch_right_hearts, 26)

    if game:get_item_assigned(1) ~= nil then
      local slot_item_1 = game:get_item_assigned(1):get_name()  
    
      local slot_icon_item_1 = sol.surface.create("items/" .. slot_item_1 .. "_" .. game:get_item_assigned(1):get_variant() .. ".png")
    -- Items in Slots zeichnen
      slot_icon_item_1:draw_region(0, 0, 16, 16, dst_surface, 9 + switch_right_hearts, 30)
    end
    
    if game:get_item_assigned(2) ~= nil then
      local slot_item_2 = game:get_item_assigned(2):get_name()  
    
      local slot_icon_item_2 = sol.surface.create("items/" .. slot_item_2 .. "_" .. game:get_item_assigned(2):get_variant() .. ".png")
    -- Items in Slots zeichnen
      slot_icon_item_2:draw_region(0, 0, 16, 16, dst_surface, 36 + switch_right_hearts, 30)
    end
    return dst_surface
  end




  return hud
end

return hud_manager