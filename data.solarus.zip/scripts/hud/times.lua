local times_builder = {}

function times_builder:new(game)
  times = {}


  function times:initialize()
    times.seconds = game:get_value("play_time_seconds")
    times.old_time = game:get_value("play_time")
  end

  function times:on_started()
    times:check()
  end

  


  function times:check()

    if times.seconds + 1 == 60 then
      game:set_value("play_time_seconds", 0)
      times.seconds = 0
      if times.old_time < 59999 then
        game:set_value("play_time", times.old_time + 1)
        times.old_time = times.old_time + 1
      end
    else
      game:set_value("play_time_seconds", times.seconds + 1)
      times.seconds = times.seconds + 1
    end


-- erneute Ueberpruefung einleiten
    sol.timer.start(times, 1000, function()

      math.random(100) 
      times:check()
    end):set_suspended_with_map(true)
  end




  times:initialize()
  
  return times
end

return times_builder

