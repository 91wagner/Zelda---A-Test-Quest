local bombs_builder = {}

function bombs_builder:new(game)
  bombs = {}


  function bombs:initialize()
    bombs.small_bomb_icon = sol.surface.create("menus/bomb_icon.png")
    bombs.bomb_text = sol.text_surface.create()
    bombs.bomb_bag_variant = game:get_item("bomb_bag"):get_variant()
    bombs.current_bombs_displayed = game:get_item("bomb_counter"):get_amount()
    bombs.surface = sol.surface.create(40, 12)
  end

  function bombs:on_started()
    bombs:check()
    bombs:rebuild_surface()
  end

  


  function bombs:check()
    local need_rebuild = false

-- Bomben-Tasche ueberpruefen
    if game:has_item("bomb_bag") then
      local bag_variant = game:get_item("bomb_bag"):get_variant()
      if bag_variant ~= bombs.bomb_bag_variant then
        need_rebuild = true
        bombs.bomb_bag_variant = bag_variant
      end
    end


-- Anzahl Bomben updaten   
    local current_bombs = game:get_item("bomb_counter"):get_amount()
    
    if current_bombs ~= bombs.current_bombs_displayed then
      need_rebuild = true
  --    if current_bombs < bombs.current_bombs_displayed then
        bombs.current_bombs_displayed = current_bombs-- bombs.current_bombs_displayed - 1
  --    else
  --      bombs.current_bombs_displayed = bombs.current_bombs_displayed + 1
  --    end
    end

-- bei Veraenderung neu bauen
    if need_rebuild then
      bombs:rebuild_surface()
    end

-- erneute Ueberpruefung einleiten
    sol.timer.start(bombs, 100, function()
      bombs:check()
    end)
  end




-- Anzeige Bauen
  function bombs:rebuild_surface()
    -- altes Bild loeschen
    bombs.surface:clear()

    -- Icon fuer Bomben
    if bombs.bomb_bag_variant ~= 0 then
      bombs.small_bomb_icon:draw(bombs.surface, 0, 0)
   

      -- Farb-Aenderung bei maximalen Bomben.
      if bombs.current_bombs_displayed == game:get_item("bomb_counter"):get_max_amount() then
        bombs.bomb_text:set_font("green_digits")
      else
        bombs.bomb_text:set_font("white_digits")
      end

      bombs.bomb_text:set_text(bombs.current_bombs_displayed)
      bombs.bomb_text:draw(bombs.surface, 9, 4)
    end
  end




  function bombs:on_draw(dst_surface)
    bombs.surface:draw(dst_surface, 16, 213)
  end


  bombs:initialize()
  
  return bombs
end

return bombs_builder

