local item_slots_builder = {}

function item_slots_builder:new(game)
  item_slots = {}


  function item_slots:initialize()
    item_slots.item_slots_icon = sol.surface.create("hud/item_slot.png")
    item_slots.nb_columns = game:get_value("nb_hearts_per_row")
    item_slots.switch_right = 0

    item_slots.items = {}
    item_slots.items["boomerang_1"] = sol.surface.create("items/boomerang_1.png")
    item_slots.items["boomerang_2"] = sol.surface.create("items/boomerang_2.png")
    item_slots.items["lamp_1"] = sol.surface.create("items/lamp_1.png")
    item_slots.items["bomb_counter_1"] = sol.surface.create("items/bomb_counter_1.png")
    item_slots.items["bow_1"] = sol.surface.create("items/bow_1.png")
    item_slots.items["bow_2"] = sol.surface.create("items/bow_2.png")

    if game:get_item_assigned(1) then
      item_slots.item_1_displayed = game:get_item_assigned(1):get_name()
      item_slots.item_1_displayed_variant = game:get_item(item_slots.item_1_displayed):get_variant()
    else 
      item_slots.item_1_displayed = nil
    end
    if game:get_item_assigned(2) then
      item_slots.item_2_displayed = game:get_item_assigned(2):get_name()
      item_slots.item_2_displayed_variant = game:get_item(item_slots.item_2_displayed):get_variant()
    else 
      item_slots.item_2_displayed = nil
    end

    item_slots.surface = sol.surface.create(60, 30)
  end

  function item_slots:on_started()
    item_slots:check()
    item_slots:rebuild_surface()
  end

  


  function item_slots:check()
    local need_rebuild = false

-- ausgeruestete Items ueberpruefen
    if game:get_item_assigned(1) then
      local item_1 = game:get_item_assigned(1):get_name()
      local item_1_variant = game:get_item(item_1):get_variant()
      if item_1 ~= item_slots.item_1_displayed  or  item_1_variant ~= item_slots.item_1_displayed_variant then
        need_rebuild = true
        item_slots.item_1_displayed = item_1
        item_slots.item_1_displayed_variant = item_1_variant
      end
    else 
      item_slots.item_1_displayed = ""
    end
    if game:get_item_assigned(2) then
      local item_2 = game:get_item_assigned(2):get_name()
      local item_2_variant = game:get_item(item_2):get_variant()
      if item_2 ~= item_slots.item_2_displayed  or  item_2_variant ~= item_slots.item_2_displayed_variant then
        need_rebuild = true
        item_slots.item_2_displayed = item_2
        item_slots.item_2_displayed_variant = item_2_variant
      end
    else 
      item_slots.item_2_displayed = ""
    end


-- bei Veraenderung neu bauen
    if need_rebuild then
      item_slots:rebuild_surface()
    end

-- erneute Ueberpruefung einleiten
    sol.timer.start(item_slots, 100, function()
      item_slots:check()
    end)
  end




-- Anzeige Bauen
  function item_slots:rebuild_surface()
    -- altes Bild loeschen
    item_slots.surface:clear()

    -- Icon fuer Item-Slots zeichnen
    item_slots.item_slots_icon:draw(item_slots.surface, 0, 0)
    item_slots.item_slots_icon:draw(item_slots.surface, 27, 0)

    -- ausgeruestete Items in Slots zeichnen
    if item_slots.item_1_displayed ~= "" then
      item_slots.items[item_slots.item_1_displayed .. "_" .. item_slots.item_1_displayed_variant]:draw(item_slots.surface, 4, 4)
    end
    if item_slots.item_2_displayed ~= "" then
      item_slots.items[item_slots.item_2_displayed .. "_" .. item_slots.item_2_displayed_variant]:draw(item_slots.surface, 31, 4)
    end
  end




  function item_slots:on_draw(dst_surface)
-- Anzeige verschieben, wenn Held in oberer linker Ecke ist.
    local hero_x, hero_y = game:get_hero():get_position()
    local camera_x, camera_y = game:get_map():get_camera_position()

    if hero_x < 50 + 10 * item_slots.nb_columns + camera_x and hero_y < 120 + camera_y then
      item_slots.switch_right = 310 - 10 * item_slots.nb_columns
    else
      item_slots.switch_right = 0
    end

    item_slots.surface:draw(dst_surface, 5 + item_slots.switch_right, 26)
  end


  item_slots:initialize()
  
  return item_slots
end

return item_slots_builder

