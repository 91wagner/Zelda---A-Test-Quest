local small_keys_builder = {}



function small_keys_builder:new(game)
  small_keys = {}


  function small_keys:initialize()
    small_keys.small_key_icon = sol.surface.create("hud/small_key_icon.png")
    small_keys.small_key_text = sol.text_surface.create()
    small_keys.small_key_text:set_font("white_digits")
    small_keys.dungeon_name_text = sol.text_surface.create({
      horizontal_alignment = "center",
    })
    small_keys.floor_text = sol.text_surface.create()
    small_keys.nb_dungeons = game:get_value("nb_dungeons_in_game") 

    small_keys.dungeon_name_displayed = false
    small_keys.floor_displayed = false
    small_keys.current_dungeon = 0
    small_keys.in_dungeon = false
    small_keys.current_small_keys_displayed = 0
    small_keys.timer = nil

    small_keys.keys = {}
    for i = 1, small_keys.nb_dungeons do
      small_keys.keys[i] = game:get_item("small_key_" .. i)
    end


    small_keys.surface = sol.surface.create(320, 240)

  end




  function game:on_map_changed(map)

    local name = map:get_world()
    local in_dungeon = name:match("^Dungeon")

    if in_dungeon then
      for i=1, small_keys.nb_dungeons do
        if name == "Dungeon_" .. i then
        
          if not small_keys.in_dungeon then
            small_keys.dungeon_name_displayed = true
            sol.timer.start(game, 4000, function()

              small_keys.dungeon_name_displayed = false
              small_keys:rebuild_surface()
            end)

            small_keys.in_dungeon = true
          end

          small_keys.current_dungeon = i

        -- sets the Dungeon Name
          local dungeon_names = {"Level 2 - Insel", "Level 1 - Piraten-Versteck", "Level 3 - Wüsten-Berg", "Level 4 - Ganons Schloss"}
          small_keys.dungeon_name_text:set_text(dungeon_names[i]) 
        end
      end
      
      -- sets the Floor Name
      local floor = map:get_floor()
      if floor == 0 then
        small_keys.floor_text:set_text("EG")
      elseif floor > 0 then
        small_keys.floor_text:set_text(floor .. ".OG")
      else
        small_keys.floor_text:set_text(-floor .. ".UG")
      end
      small_keys.floor_displayed = true
    
      if small_keys.timer ~= nil and small_keys.timer:get_remaining_time()>0 then
        small_keys.timer:set_remaining_time(4000)
      else
        small_keys.timer = sol.timer.start(game, 4000, function()

          small_keys.floor_displayed = false
          small_keys.rebuild_surface()
        end)
      end

      small_keys:check()

    else
      
      small_keys.in_dungeon = false
      small_keys.dungeon_name_displayed = false
      small_keys.floor_displayed = false
    end

    small_keys:rebuild_surface()
  end




  function small_keys:check()
     
    if small_keys.in_dungeon then
      
      if small_keys.keys[small_keys.current_dungeon]:get_amount() ~= small_keys.current_small_keys_displayed then
        small_keys.current_small_keys_displayed = small_keys.keys[small_keys.current_dungeon]:get_amount()

        small_keys:rebuild_surface()
      end 

    -- scedule new check
      sol.timer.start(1000, function()
      
        small_keys:check()
     
      end)
    end
  end


  function small_keys:rebuild_surface()


    small_keys.surface:clear()
  
    if small_keys.in_dungeon then
      small_keys.small_key_text:set_text(small_keys.current_small_keys_displayed)
      
      small_keys.small_key_icon:draw(small_keys.surface, 279, 225)
      small_keys.small_key_text:draw(small_keys.surface, 290, 230)

      if small_keys.dungeon_name_displayed then
        small_keys.dungeon_name_text:draw(small_keys.surface, 160, 50)
      end
      if small_keys.floor_displayed then
        small_keys.floor_text:draw(small_keys.surface, 10, 60)
      end
    end
  end




  function small_keys:on_draw(dst_surface)

    small_keys.surface:draw(dst_surface, 0, 0)
  end


  small_keys:initialize()
  
  return small_keys
end

return small_keys_builder

