local rupees_builder = {}

function rupees_builder:new(game)
  rupees = {}


  function rupees:initialize()
    rupees.rupee_icon = sol.surface.create("hud/rupee_icon.png")
    rupees.rupee_text = sol.text_surface.create()
    rupees.rupee_bag_variant = game:get_item("rupee_bag"):get_variant()
    rupees.current_money_displayed = game:get_money()
    rupees.surface = sol.surface.create(40, 12)
  end

  function rupees:on_started()
    rupees:check()
    rupees:rebuild_surface()
  end

  


  function rupees:check()
    local need_rebuild = false

-- Rubin-Beutel ueberpruefen
    if game:has_item("rupee_bag") then
      local bag_variant = game:get_item("rupee_bag"):get_variant()
      if bag_variant ~= rupees.rupee_bag_variant then
        need_rebuild = true
        rupees.rupee_bag_variant = bag_variant
      end
    end


-- Anzahl Rubine updaten   
    local current_money = game:get_money()
    
    if current_money ~= rupees.current_money_displayed then
      need_rebuild = true
      if current_money < rupees.current_money_displayed then
        rupees.current_money_displayed = rupees.current_money_displayed - 1
      else
        rupees.current_money_displayed = rupees.current_money_displayed + 1
      end

      if rupees.current_money_displayed == current_money or rupees.current_money_displayed % 3 == 0 then
        sol.audio.play_sound("rupee_counter_end")
      end
    end

-- bei Veraenderung neu bauen
    if need_rebuild then
      rupees:rebuild_surface()
    end

-- erneute Ueberpruefung einleiten
    sol.timer.start(rupees, 40, function()
      rupees:check()
    end)
  end




-- Anzeige Bauen
  function rupees:rebuild_surface()
    -- altes Bild loeschen
    rupees.surface:clear()

    -- Icon fuer Rubin-Beutel
    if rupees.rupee_bag_variant ~= 0 then
      rupees.rupee_icon:draw_region(12 * (rupees.rupee_bag_variant - 1), 0, 12, 12, rupees.surface, 0, 0)
    end

    -- Farb-Aenderung bei maximalem Geld.
    if rupees.current_money_displayed == game:get_max_money() then
      rupees.rupee_text:set_font("green_digits")
    else
      rupees.rupee_text:set_font("white_digits")
    end
    rupees.rupee_text:set_text(rupees.current_money_displayed)
    rupees.rupee_text:draw(rupees.surface, 15, 5)
  end





  function rupees:on_draw(dst_surface)
    rupees.surface:draw(dst_surface, 10, 225)
  end


  rupees:initialize()
  
  return rupees
end

return rupees_builder

