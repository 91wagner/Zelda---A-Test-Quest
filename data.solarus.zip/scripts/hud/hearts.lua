local hearts_builder = {}

function hearts_builder:new(game)
  local hearts = {}

  function hearts:initialize()
    hearts.nb_columns = game:get_value("nb_hearts_per_row")
    hearts.hearts_icon = sol.surface.create("hud/hearts.png")
    hearts.max_life_displayed = game:get_max_life()
    hearts.current_life_displayed = game:get_life()
    hearts.surface = sol.surface.create(10 * (hearts.nb_columns), 20)
    hearts.switch_right_hearts = 0
  end



  function hearts:on_started()
    hearts:danger_sound()
    hearts:check()
    hearts:rebuild_surface()
  end




  function hearts:check()
    local need_rebuild = false
-- Maximale Energie updaten
    local max_life = game:get_max_life()
    if max_life ~= hearts.max_life_displayed then 
      need_rebuild = true
      hearts.max_life_displayed = max_life
    end

-- aktuelle Energie updaten
    local current_life = game:get_life()
    if current_life ~= hearts.current_life_displayed then
      need_rebuild = true
      if current_life > hearts.current_life_displayed then
        hearts.current_life_displayed = hearts.current_life_displayed + 1
        if hearts.current_life_displayed % 4 == 0 and game:is_started() then
          sol.audio.play_sound("heart")
        end
      else
        hearts.current_life_displayed = hearts.current_life_displayed - 1 
      end
    end
    

-- Warnton
    if hearts.current_life_displayed <= hearts.max_life_displayed / 3.0 and hearts.current_life_displayed ~= 0 and hearts.current_life_displayed <= 12 then
      hearts.danger_sound_repeat = true
    else
      hearts.danger_sound_repeat = false
    end

-- Anzeige neu Aufbauen
    if need_rebuild then
      hearts:rebuild_surface()
    end

-- Anzeige erneut ueberpruefen
    sol.timer.start(hearts, 80, function()
      hearts:check()
    end)

  end






-- Anzeige Bauen
  function hearts:rebuild_surface()
-- Herzanzeige oben links (rechts) darstellen
    local full_hearts = math.floor(hearts.current_life_displayed / 4)
    local rest_hearts = hearts.current_life_displayed % 4
    --leere Herzen
    for i = 1, hearts.max_life_displayed / 4 do
      if i <= hearts.nb_columns then
        hearts.hearts_icon:draw_region(0, 9, 9, 9, hearts.surface, (i-1) * 10, 0)
      else
        hearts.hearts_icon:draw_region(0, 9, 9, 9, hearts.surface, (i-1 - hearts.nb_columns) * 10, 10)
      end  
    end
    -- volle Herzen
    for i = 1, math.floor(hearts.current_life_displayed / 4) do
      if i <= hearts.nb_columns then
        hearts.hearts_icon:draw_region(27, 0, 9, 9, hearts.surface, (i-1)*10, 0)
      else
        hearts.hearts_icon:draw_region(27, 0, 9, 9, hearts.surface, (i-1 - hearts.nb_columns)*10, 10)
      end
    end
    -- Teilherz
    if rest_hearts ~= 0 then
      if full_hearts < hearts.nb_columns then
        hearts.hearts_icon:draw_region(9 * (rest_hearts - 1), 0, 9, 9, hearts.surface, 10 * (full_hearts), 0)
      else
        hearts.hearts_icon:draw_region(9 * (rest_hearts - 1), 0, 9, 9, hearts.surface, 10 * (full_hearts  - hearts.nb_columns), 10)
      end
    end

  end


-- Funktionen fuer den Warnton 

  function hearts:danger_sound()

    if hearts.danger_sound_repeat == true then
      sol.audio.play_sound("danger")
      if hearts.current_life_displayed <= 4 and game:get_max_life()>20 then
        sol.timer.start(200, function()

          sol.audio.play_sound("danger")
        end)
      end 
    end

    sol.timer.start(hearts, 1000, function()
        
      hearts:danger_sound()
    end)
  end



  function hearts:on_draw(dst_surface)

-- Anzeige verschieben, wenn Held in oberer linker Ecke ist.
    local hero_x, hero_y = game:get_hero():get_position()
    local camera_x, camera_y = game:get_map():get_camera_position()

    if hero_x < 50 + 10 * hearts.nb_columns + camera_x and hero_y < 120 + camera_y then
      hearts.switch_right_hearts = 310 - 10 * hearts.nb_columns
    else
      hearts.switch_right_hearts = 0
    end


    hearts.surface:draw(dst_surface, hearts.switch_right_hearts + 5, 5)
  end





  hearts:initialize()
  return hearts

end

return hearts_builder







