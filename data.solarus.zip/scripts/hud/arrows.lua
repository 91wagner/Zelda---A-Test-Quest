local arrows_builder = {}

function arrows_builder:new(game)
  arrows = {}


  function arrows:initialize()
    arrows.small_arrow_icon = sol.surface.create("menus/arrow_icon.png")
    arrows.arrow_text = sol.text_surface.create()
    arrows.quiver_variant = game:get_item("quiver"):get_variant()
    arrows.current_arrows_displayed = game:get_item("bow"):get_amount()
    arrows.surface = sol.surface.create(40, 12)
  end

  function arrows:on_started()
    arrows:check()
    arrows:rebuild_surface()
  end

  


  function arrows:check()
    local need_rebuild = false

-- Koecher ueberpruefen
    if game:has_item("quiver") then
      local bag_variant = game:get_item("quiver"):get_variant()
      if bag_variant ~= arrows.quiver_variant then
        need_rebuild = true
        arrows.quiver_variant = bag_variant
      end
    end


-- Anzahl Pfeile updaten   
    local current_arrows = game:get_item("bow"):get_amount()
    
    if current_arrows ~= arrows.current_arrows_displayed then
      need_rebuild = true
    --  if current_arrows < arrows.current_arrows_displayed then
        arrows.current_arrows_displayed =current_arrows-- arrows.current_arrows_displayed - 1
    --  else
   --     arrows.current_arrows_displayed = arrows.current_arrows_displayed + 1
    --  end
    end

-- bei Veraenderung neu bauen
    if need_rebuild then
      arrows:rebuild_surface()
    end

-- erneute Ueberpruefung einleiten
    sol.timer.start(arrows, 100, function()
      arrows:check()
    end)
  end




-- Anzeige Bauen
  function arrows:rebuild_surface()
    -- altes Bild loeschen
    arrows.surface:clear()

    -- Icon fuer Bomben
    if arrows.quiver_variant ~= 0 then
      arrows.small_arrow_icon:draw(arrows.surface, 0, 0)
   

      -- Farb-Aenderung bei maximalen Bomben.
      if arrows.current_arrows_displayed == game:get_item("bow"):get_max_amount() then
        arrows.arrow_text:set_font("green_digits")
      else
        arrows.arrow_text:set_font("white_digits")
      end

      arrows.arrow_text:set_text(arrows.current_arrows_displayed)
      arrows.arrow_text:draw(arrows.surface, 9, 4)
    end
  end




  function arrows:on_draw(dst_surface)
    arrows.surface:draw(dst_surface, 16, 201)
  end


  arrows:initialize()
  
  return arrows
end

return arrows_builder

