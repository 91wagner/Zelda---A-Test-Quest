-- Script that creates a game ready to be played.

-- Usage:
-- local game_manager = require("scripts/game_manager")
-- local game = game_manager:create("savegame_file_name")
-- game:start()

local dialog_box_manager = require("scripts/dialog_box")

local game_manager = {}






-- Sets initial values for a new savegame of this quest.
local function initialize_new_savegame(game)
  game:set_starting_location("Spiel1/overworld_1_1")
  game:set_max_money(99)
  game:set_max_life(12)
  game:set_life(24)
  game:set_value("nb_piece_of_heart", 0)

  -- gibt an, wie of man gestorben ist
  game:set_value("nb_deaths", 0)

  -- gibt die Spielzeit an
  game:set_value("play_time", 0)
  game:set_value("play_time_seconds", 0)

  -- gibt an, wie viele Dungeons existieren
  game:set_value("nb_dungeons_in_game", 4)

  -- gibt an, wie viele Herzen pro Zeile angezeigt werden sollen
  game:set_value("nb_hearts_per_row", 6)
  
  game:set_ability("lift", 0)
  game:set_ability("tunic", 1)
  game:set_value("fairy_possessed", false)

-- Fuer das Gespraech mit dem Dieb im Shop  
  game:set_value("shop_thief_got_item", false)

-- gibt an, wie oft man die letzte Hoehle geschafft hat
  game:set_value("final_cave_mastered_count", 0)
end







-- Creates a game ready to be played.
function game_manager:create(file)

  -- Create the game (but do not start it).
  local exists = sol.game.exists(file)
  local game = sol.game.load(file)
  if not exists then
    -- This is a new savegame file.
    initialize_new_savegame(game)
  end
 
  local dialog_box
  local pause_manager = require("scripts/menus/pause_menu")
  local pause_menu
  sol.main.load_file("scripts/menus/game_over.lua")(game)

  local hearts_builder = require("scripts/hud/hearts")
  local hearts
  local rupees_builder = require("scripts/hud/rupees")
  local rupees
  local bombs_builder = require("scripts/hud/bombs")
  local bombs
  local arrows_builder = require("scripts/hud/arrows")
  local arrows
  local small_keys_builder = require("scripts/hud/small_keys")
  local small_keys
  local item_slots_builder = require("scripts/hud/item_slots")
  local item_slots
  local times_builder = require("scripts/hud/times")
  local times


  -- Function called when the player runs this game.
  function game:on_started()

    dialog_box = dialog_box_manager:create(game)
    pause_menu = pause_manager:create(game)

    hearts = hearts_builder:new(game)
    sol.menu.start(game, hearts)

    rupees = rupees_builder:new(game)
    sol.menu.start(game, rupees)

    bombs = bombs_builder:new(game)
    sol.menu.start(game, bombs)

    arrows = arrows_builder:new(game)
    sol.menu.start(game, arrows)

    times = times_builder:new(game)
    sol.menu.start(game, times)

    small_keys = small_keys_builder:new(game)
    sol.menu.start(game, small_keys)

    item_slots = item_slots_builder:new(game)
    sol.menu.start(game, item_slots)
  end

  -- Function called when the game stops.
  function game:on_finished()

    dialog_box:quit()
    dialog_box = nil
  end




-- Speichern und Item-Menue

  function game:on_paused()
    sol.menu.start(game, pause_menu)
  end

  function game:on_unpaused()
    sol.menu.stop(pause_menu)
  end










  
  return game
end

return game_manager
