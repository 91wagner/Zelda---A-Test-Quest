local enemy = ...
local game = enemy:get_game()
-- A blue flame shot by another enemy.

function enemy:on_created()

  self:set_life(1)
  if game:get_value("difficulty") == "easy" then
    self:set_damage(4)
  else
    self:set_damage(8)
  end
  self:create_sprite("enemies/blue_flame")
  self:set_size(16, 16)
  self:set_origin(8, 13)
  self:set_invincible()
  self:set_obstacle_behavior("flying")
  self:set_layer_independent_collisions(true)
  self:set_optimization_distance(0)
end

function enemy:on_movement_finished(movement)

  self:remove()
end

function enemy:go(angle)

  local m = sol.movement.create("straight")
  m:set_speed(192)
  m:set_angle(angle)
  m:set_ignore_obstacles(true)
  m:set_max_distance(320)
  m:start(self)
end

