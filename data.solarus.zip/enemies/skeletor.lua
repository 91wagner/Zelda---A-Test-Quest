local enemy = ...
local map = enemy:get_map()
local hero = map:get_entity("hero")
-- Skeletor.

function enemy:on_created()
  enemy:create_sprite("enemies/skeletor")
  enemy:set_life(3)
  enemy:set_damage(2)
end

function enemy:on_restarted()
  local movement = sol.movement.create("target")
  movement:set_speed(24)
  movement:start(enemy)
  
  
end

function enemy:on_movement_changed(movement)

  local direction4 = movement:get_direction4()
  enemy:get_sprite():set_direction(direction4)
end