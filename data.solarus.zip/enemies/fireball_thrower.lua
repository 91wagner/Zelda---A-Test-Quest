local enemy = ...
local map = enemy:get_map()
local hero = map:get_entity("hero")


local fireball_thrown = false
local stop_attacking = false
-- wirft die Gegner "fireball"
function enemy:on_created()
  self:create_sprite("enemies/fireball_thrower")
  self:set_life(1)
  self:set_damage(1)
  self:set_size(16,16)
  self:set_origin(8,12)
  self:set_invincible()
end



function enemy:on_restarted()
  
  if not stop_attacking and not fireball_thrown then
    self:check_hero()

    sol.timer.start(3000+math.random(20)*100, function()

      fireball_thrown = false
      self:restart()
    end)
  end
end

function enemy:check_hero()
  fireball_thrown = true

  local enemy_x, enemy_y, layer = self:get_position()
  local hero_x, hero_y, hero_layer = hero:get_position()

  local angle = self:get_angle(hero_x, hero_y)
  local near_hero = layer == hero_layer and self:is_in_same_region(hero) and self:get_distance(hero) < 200
  
  local x_create = 20 * math.cos(angle)
  local y_create = -4-20 * math.sin(angle)
  

  if near_hero then
    self:create_enemy({
      breed = "fireball",
      x = x_create,
      y = y_create
    })

  end
end


function enemy:on_disabled()

  stop_attacking = true
end

function enemy:on_enabled()

  stop_attacking = false
end
