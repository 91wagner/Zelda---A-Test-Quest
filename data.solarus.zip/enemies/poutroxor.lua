local enemy = ...
local game = enemy:get_game()
-- Poutroxor: an evil giant bird from Newlink.
-- Phase 1: a skeleton is on the bird and has to be killed with arrows.
-- Phase 2: once the skeleton is dead, the bird moves faster, throws blue flames and can be killed by shooting arrows in his head.

local bird, head, skeleton  -- Sprites.
local phase = 1
local nb_flames_created = 0
local max_flames_created = 10

function enemy:on_created()

  if game:get_value("difficulty") == "easy" then
    self:set_life(16)
    self:set_damage(2)
  else
    self:set_life(20)
    self:set_damage(4)
  end
  bird = self:create_sprite("enemies/poutroxor")
  head = self:create_sprite("enemies/poutroxor_head")
  skeleton = self:create_sprite("enemies/poutroxor_skeleton")
  self:set_size(16, 16)
  self:set_origin(8, 8)
  self:set_obstacle_behavior("flying")
  self:set_pushed_back_when_hurt(false)
  self:set_push_hero_on_sword(true)

  self:set_invincible()
  self:set_attack_consequence("sword", "protected")
  self:set_attack_consequence("hookshot", "protected")
  self:set_attack_consequence("boomerang", "protected")
  self:set_attack_consequence("arrow", "ignored")
  self:set_attack_consequence_sprite(skeleton, "arrow", 1)
end

function enemy:on_restarted()

  if phase == 1 then
    local m = sol.movement.create("random")
    m:set_speed(32)
    m:start(self)
    sol.timer.start(self, math.random(2000, 3000), function()
      self:skeleton_attack()
    end)
  else
    local m = sol.movement.create("random")
    m:set_speed(64)
    m:start(self)
    sol.timer.start(self, math.random(3000, 5000), function()
      self:big_attack()
    end)
  end
end

-- Make the skeleton shoot a blue flame.
function enemy:skeleton_attack()

  skeleton:set_animation("attack")
  sol.audio.play_sound("ice")
  sol.timer.start(self, 500, function()
    skeleton:set_animation("walking")
    nb_flames_created = nb_flames_created + 1
    local son_name = self:get_name() .. "_son_" .. nb_flames_created
    local son = self:create_enemy{
      name = son_name,
      breed = "blue_flame",
      x = 0,
      y = -48,
      layer = 2,
    }
    local angle = son:get_angle(self:get_map():get_entity("hero"))
    son:go(angle)
    sol.timer.start(self, math.random(1000, 3000), function()
      self:skeleton_attack()
    end)
  end)
end

function enemy:on_hurt(attack)

  if phase == 1 and self:get_life() <= 12 then
    self:stop_movement()
    sol.audio.play_sound("enemy_killed")
    skeleton:set_animation("hurt")
    phase = 2
    self:remove_sprite(skeleton)
    self:get_map():remove_entities(self:get_name() .. "_son")
    skeleton = nil
    self:set_attack_consequence_sprite(head, "arrow", 1)
    self:set_attack_consequence_sprite(head, "sword", 1)
  elseif self:get_life() <= 0 then
    self:get_map():remove_entities(self:get_name() .. "_son")
  end
end

-- Makes the bird throw several blue flames.
function enemy:big_attack()

  nb_flames_created = 0
  self:stop_movement()
  head:set_animation("attack")
  sol.audio.play_sound("lamp")
  sol.timer.start(self, 500, function() self:repeat_flame() end)
end

function enemy:repeat_flame()

  if nb_flames_created <= max_flames_created then
    local son_name = self:get_name() .. "_son_" .. nb_flames_created
    local angle = math.random(30, 90) * math.pi / 40
    nb_flames_created = nb_flames_created + 1
    local son = self:create_enemy{
      name = son_name,
      breed = "blue_flame",
      x = 0,
      y = 16,
    }
    son:go(angle)
    sol.audio.play_sound("lamp")
    sol.timer.start(self, 150, function() self:repeat_flame() end)
  else
    sol.timer.start(self, 500, function() self:restart() end)
  end
end

