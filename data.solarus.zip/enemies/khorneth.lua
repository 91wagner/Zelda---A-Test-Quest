local enemy = ...
local game = enemy:get_game()
-- The boss Khorneth from @PyroNet.
-- Khorneth has two blades that must be destroyed first.

-- State.
local left_blade_life
local right_blade_life
local blade_attack = false

-- Sprites.
local main_sprite = enemy:create_sprite("enemies/khorneth")
local left_blade_sprite = enemy:create_sprite("enemies/khorneth_left_blade")
local right_blade_sprite = enemy:create_sprite("enemies/khorneth_right_blade")
-- When a blade sprite has the same animation than the
-- main sprite, synchronize their frames
left_blade_sprite:synchronize(main_sprite)
right_blade_sprite:synchronize(main_sprite)

-- Properties.

if game:get_value("difficulty") == "easy" then
  enemy:set_life(6)
  enemy:set_damage(3)
  left_blade_life = 4
  right_blade_life = 4
else
  enemy:set_life(8)
  enemy:set_damage(4)
  left_blade_life = 5
  right_blade_life = 5
end
enemy:set_pushed_back_when_hurt(false)
enemy:set_size(40, 48)
enemy:set_origin(20, 25)
enemy:set_invincible()
enemy:set_attack_consequence_sprite(left_blade_sprite, "sword", "custom")
enemy:set_attack_consequence_sprite(right_blade_sprite, "sword", "custom")
enemy:set_attack_consequence("boomerang", "custom")

function main_sprite:on_animation_finished(animation)
  if blade_attack then
    blade_attack = false
    enemy:restart()
  end
end

function enemy:on_restarted()

  local m = sol.movement.create("random_path")
  m:set_speed(72)
  m:start(self)

  -- Schedule a blade attack
  if enemy:has_blade() then
    local delay = 1000 * (1 + math.random(4))
    sol.timer.start(enemy, delay, function() enemy:start_blade_attack() end)
    blade_attack = false
  end
end

function enemy:has_left_blade()
  return left_blade_life > 0
end

function enemy:has_right_blade()
  return right_blade_life > 0
end

function enemy:has_blade()
  return enemy:has_left_blade() or enemy:has_right_blade()
end

-- The enemy receives an attack whose consequence is "custom".
function enemy:on_custom_attack_received(attack, sprite)

  if attack == "boomerang" then
    enemy:stop_movement()
    if not enemy:has_blade() then
      sol.timer.start(enemy, 2000, function()
        enemy:restart()
      end)
    end
  end

  if enemy:has_left_blade()
    and sprite == left_blade_sprite
    and sprite:get_animation() ~= "stopped" 
    and attack ~= "boomerang" then

    sprite:set_animation("hurt")
    main_sprite:set_animation("stopped")
    if enemy:has_right_blade() then
      right_blade_sprite:set_animation("stopped")
    end
    enemy:stop_movement()
    sol.audio.play_sound("boss_hurt")
    left_blade_life = left_blade_life - 1
    sol.timer.start(enemy, 400, function() enemy:stop_hurting_left_blade() end)

  elseif enemy:has_right_blade()
    and sprite == right_blade_sprite
    and sprite:get_animation() ~= "stopped"
    and attack ~= "boomerang" then

    sprite:set_animation("hurt")
    main_sprite:set_animation("stopped")
    if enemy:has_left_blade() then
      left_blade_sprite:set_animation("stopped")
    end
    enemy:stop_movement()
    sol.audio.play_sound("boss_hurt")
    right_blade_life = right_blade_life - 1
    sol.timer.start(enemy, 400, function() enemy:stop_hurting_right_blade() end)
  end
end

function enemy:start_blade_attack()

  if enemy:has_blade() and not blade_attack then

    blade_attack = true
    local side
    if not enemy:has_right_blade() then
      side = 0
    elseif not enemy:has_left_blade() then
      side = 1
    else
      side = math.random(2) - 1
    end

    if side == 0 then
      animation = "left_blade_attack"
    else
      animation = "right_blade_attack"
    end

    main_sprite:set_animation(animation)
    if enemy:has_left_blade() then
      left_blade_sprite:set_animation(animation)
    end
    if enemy:has_right_blade() then
      right_blade_sprite:set_animation(animation)
    end

    enemy:stop_movement()
  end
end

function enemy:stop_hurting_left_blade()

  enemy:restart()
  if left_blade_life <= 0 then
    sol.audio.play_sound("stone")
    enemy:remove_sprite(left_blade_sprite)

    if not enemy:has_right_blade() then
      enemy:start_final_phase()
    end
  end
end

function enemy:stop_hurting_right_blade()

  enemy:restart()
  if right_blade_life <= 0 then
    sol.audio.play_sound("stone")
    enemy:remove_sprite(right_blade_sprite)

    if not enemy:has_left_blade() then
      enemy:start_final_phase()
    end
  end
end

function enemy:start_final_phase()

  enemy:set_attack_consequence("sword", 1)
end

