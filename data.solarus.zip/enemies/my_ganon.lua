local enemy = ...
local map = enemy:get_map()
local game = enemy:get_game()
local hero = map:get_entity("hero")

local x_pos = {232, 160, 88, 160, 160}
local y_pos = {141, 85, 141, 197, 141}

local current_number_attacks = 10

local next_position = 0
local prep_move = false
local prep_attack = false
local ganon_pos = 0

-- Final Boss Ganon

-- Phase 1: Ganon uses Zelda as shield against arrows

-- Phase 2: Ganon can be hit with sword

-- Phase 3: Ganon unlights the torches
-- they have to be lit, to make him vulnarable to sword

-- Phase 4: Ganon is defeated and Zelda will attack



local phase = 1
local nb_zeldas = 0
local is_attacking_phase_1 = false
local is_jumping = false
local is_dark = false
local prepare_unlight_torches = false
local just_restarted = false
local difficulty


function enemy:on_created()

  difficulty = game:get_value("difficulty")
  if difficulty == "easy" then
    self:set_damage(6)
  else
    self:set_damage(10)
  end
  self:set_life(100)
  self:set_optimization_distance(0)
  self:set_size(32, 32)
  self:set_origin(16, 29)
  self:set_invincible()
  self:set_attack_consequence("sword", "protected")
  self:set_attack_consequence("arrow", 1)
  self:set_attack_consequence("boomerang", "protected")
  self:set_attack_consequence("thrown_item", "protected")
  self:set_hurt_style("boss")
  self:set_pushed_back_when_hurt(false)
  self:set_push_hero_on_sword(true)
  self:set_obstacle_behavior("flying");

  
  current_number_attacks = 10

  local sprite = self:create_sprite("enemies/ganon")

end


function enemy:on_enabled()

  self:restart()
end


function enemy:check_direction(test)

  local x_g, y_g, layer_g = test:get_position()
  local movement = test:get_movement()

  if x_g < 90 then
    enemy:set_position(x_g+10, y_g, layer_g)
  end
  if x_g > 220 then
    enemy:set_position(x_g-10, y_g, layer_g)
  end
  if x_g < 100 then
    movement:set_angle(0)
  end
  if x_g > 210 then
    movement:set_angle(math.pi)
  end
  sol.timer.start(map, 200, function() 
    enemy:check_direction(test) 
  end)

  if not is_attacking_phase_1 and phase == 1 then
    is_attacking_phase_1 = true
    sol.timer.start(map, 2000 + math.random(3)*1000, function()
      local son = self:create_enemy{
        name = "bat",
        breed = "fire_bat",
        x = 0,
        y = 0,
        layer = 1,
      }
      if difficulty == "easy" then
        son:set_damage(4)
      else
        son:set_damage(8)
      end
      if math.random(8)== 1 or game:get_item("bow"):get_amount() < 10 then
        son:set_treasure("arrow", 2)
      elseif math.random(4)== 1 then
        son:set_treasure("heart", 1)
      end
      son:go_hero()
      is_attacking_phase_1 = false
    end)
  end
end


function enemy:on_restarted()

  if phase == 1 and not just_restarted then
    just_restarted = true
    local movement = sol.movement.create("straight")

    if enemy:get_life() > 97 then
      movement:set_speed(32)
    elseif enemy:get_life() > 95 then
      movement:set_speed(40)
    elseif enemy:get_life() > 80 then
      movement:set_speed(48)
    else
      phase = 2
      is_attacking_phase_1 = false
    end

    if math.random(2) == 1 then
      movement:set_angle(0)
    else
      movement:set_angle(math.pi)
    end

    movement:start(enemy)
    
    if phase == 1 then
      enemy:check_direction(enemy)
    elseif phase == 2 then
      sol.timer.stop_all(map)
      enemy:stop_movement()
      map:get_entity("spikes"):set_enabled(false)
      map:get_entity("puppet_" .. nb_zeldas):remove()
      enemy:set_attack_consequence("arrow", "protected")
      enemy:set_attack_consequence("sword", 1)
   
      if difficulty == "easy" then
        enemy:set_life(70)
      else
        enemy:set_life(80)
      end
      enemy:set_position(x_pos[5], y_pos[5], 1)
      ganon_pos = 5
      game:start_dialog("ganon.2", function()

        prep_move = true
        enemy:restart()
        sol.audio.play_music("ganon_battle")
      end)
    end
    just_restarted = false



-- phase 2
  elseif phase == 2 and not just_restarted then
    just_restarted = true
    if prep_move then
      prep_move = false
      ganon_pos = math.random(5)

      local mg = sol.movement.create("target")
      mg:set_target(x_pos[ganon_pos], y_pos[ganon_pos])
      mg:set_speed(80+math.random(4)*8)
      enemy:set_invincible()

      mg:start(enemy, function()
           
        enemy:set_attack_consequence("sword", 1) 
        prep_attack = true
        enemy:restart()

-- scedule new move
        sol.timer.start(map, 2500 + 500*math.random(4), function()
          
          prep_move = true
          sol.timer.stop_all(map)
          enemy:restart()
        end)
      end)
    end

    if difficulty == "easy" and enemy:get_life() < 50 then
      current_number_attacks = 20
    end

    if difficulty == "normal" and enemy:get_life() < 55 then
      current_number_attacks = 20
    end

    if prep_attack then
      prep_attack = false
      for i=1, current_number_attacks do
        sol.timer.start(map, 3000*i / current_number_attacks, function()

        local ma = sol.movement.create("straight")
        
        if ganon_pos == 5 then
          ma:set_angle(2*math.pi*(math.random(32)-1)/32)
        else
          ma:set_angle(ganon_pos*math.pi/2 + math.pi*(math.random(8)-1)/8)
        end
        ma:set_max_distance(320)
        ma:set_speed(104+math.random(4)*4)
        ma:set_ignore_obstacles(true)
 
        local son = enemy:create_enemy({
          name = "bat",
          breed = "fire_bat",
          x = 0,
          y = -8,
          layer = 1,
        })
        if difficulty == "easy" then
          son:set_damage(4)
        else
          son:set_damage(8)
        end      
        ma:start(son)
          
        end)
      end  
    end


    if enemy:get_life() < 30 then
      if difficulty == "easy" then
        enemy:set_life(15)
      else
        enemy:set_life(25)
      end

      phase = 3
    end

    if phase == 3 then
      is_dark = true
      hero:freeze()
      sol.audio.stop_music()
      sol.timer.stop_all(map)
      self:get_movement():stop()
      self:set_position(x_pos[5],y_pos[5],1)
      if difficulty == "easy" then
        current_number_attacks = 20
      else
        current_number_attacks = 30
      end

      game:start_dialog("ganon.3", function() 

        local order = {1,3,2,4}
        for i=1, 4 do
          sol.timer.start(game, 500*i, function()
            map:get_entity("torch_" .. order[i]):get_sprite():set_animation("unlit")
            sol.audio.play_sound("lamp")
            if i==4 then
              sol.audio.play_music("ganon_battle")
              game:set_value("is_dark", true)
              enemy:set_visible(false)
              hero:unfreeze()
              just_restarted = false
              prep_move = true
              enemy:restart()
            end
          end)
        end
      end)
    end
    just_restarted = false





-- phase 3
  elseif phase == 3 and not just_restarted then
    just_restarted = true

    if prepare_unlight_torches then
      prepare_unlight_torches = false
      
      if not game:get_value("is_dark") then
        enemy:set_invincible()
        local munlight = sol.movement.create("target")
        munlight:set_target(x_pos[5], y_pos[5])
        munlight:set_speed(88)

        munlight:start(enemy, function()

          local order = {1,3,2,4}
          for i=1, 4 do
            sol.timer.start(game, 500*i, function()
              map:get_entity("torch_" .. order[i]):get_sprite():set_animation("unlit")
              sol.audio.play_sound("lamp")
              if i==4 then
                game:set_value("is_dark", true)
                enemy:set_visible(false)
              end
            end)
          end
        end)
      end
    end

    if prep_move then
      
      prep_move = false
      ganon_pos = math.random(5)

      local mg = sol.movement.create("target")
      mg:set_target(x_pos[ganon_pos], y_pos[ganon_pos])
      mg:set_speed(80+math.random(4)*8)
      enemy:set_invincible()

      mg:start(enemy, function()
        
        if enemy:is_visible() then
          enemy:set_attack_consequence("sword", 1) 
        end
        prep_attack = true
        enemy:restart()

-- scedule new move
        sol.timer.start(map, 2500 + 500*math.random(4), function()
          
          prep_move = true
          sol.timer.stop_all(map)
          enemy:restart()
        end)
      end)
    end


    if prep_attack then
      prep_attack = false
      for i=1, current_number_attacks do
        sol.timer.start(map, 3000*i / current_number_attacks, function()

        local ma = sol.movement.create("straight")
        
        if ganon_pos == 5 then
          ma:set_angle(2*math.pi*(math.random(32)-1)/32)
        else
          ma:set_angle(ganon_pos*math.pi/2 + math.pi*(math.random(8)-1)/8)
        end
        ma:set_max_distance(320)
        ma:set_speed(104+math.random(4)*4)
        ma:set_ignore_obstacles(true)
 
        local son = enemy:create_enemy({
          name = "bat",
          breed = "fire_bat",
          x = 0,
          y = -8,
          layer = 1,
        })
        if difficulty == "easy" then
          son:set_damage(4)
        else
          son:set_damage(8)
        end      
        
        ma:start(son)
          
        end)
      end  
    end

    just_restarted = false
  end
end




function enemy:on_hurt()

  enemy:set_invincible()
  if phase >1 then
    sol.timer.stop_all(map)
    prep_move = true
    prep_attack = true
  end
  sol.timer.start(map, 1500, function()
    
    if phase == 1 then
      enemy:set_attack_consequence("arrow", 1)
    elseif phase == 3 then
      prepare_unlight_torches = true
      enemy:restart()
    end
  end)
end





function enemy:on_movement_changed(movement)

  -- Take the appropriate sprite direction.
  local direction4 = movement:get_direction4()
  local sprite = self:get_sprite()
  if direction4 == 1 then
    sprite:set_direction(1)
  else
    sprite:set_direction(0)
  end

  if phase == 1 then
  -- create Zelda-Shield
    if nb_zeldas ~= 0 then
      map:get_entity("puppet_" .. nb_zeldas):remove()
    end
    nb_zeldas = nb_zeldas + 1
    local zelda_shield = enemy:create_enemy({
      name = "puppet_" .. nb_zeldas,
      breed = "zelda_puppet",
      direction = 3,
      x = 0,
      y = 24
    })
  
    local m_zelda = sol.movement.create("straight")
    m_zelda:set_speed(movement:get_speed())
    m_zelda:set_angle(movement:get_angle())
    m_zelda:start(zelda_shield)
  elseif phase == 2 then
    
  end
end


function enemy:on_movement_finished()

  if phase == 2 then
    self:get_sprite():set_direction((ganon_pos + 1)%4)
  end
end


for i = 1, 4 do

  local entity = map:get_entity("torch_" .. i)
  function entity:on_collision_fire()

    if game:get_value("is_dark") and light_torch("torch_", i, 0) then
      game:set_value("is_dark", false)
      enemy:set_visible()
      enemy:set_attack_consequence("sword", 1)
    end
  end
end





-- entzündet die Fackel mit dem Namen 'torch_prefix' .. 'torch_number' für eine Zeit 'time' und überprüft, ob alle Fackeln mit dem Präfix 'torch_prefix' entzündet sind. Wenn dies der Fall ist, liefert die Funktion 'true' zurück, ansonsten 'false'
function light_torch(torch_prefix, torch_number, time)

  local sprite = map:get_entity(torch_prefix .. torch_number):get_sprite()

  local all_lit = true
  if sprite:get_animation() == "unlit" then
    sprite:set_animation("lit")
    if time > 0 then
      sol.timer.start(time, function()
        sprite:set_animation("unlit")
      end)
    end
  else
    all_lit = false
  end
 
  
  for entities in map:get_entities(torch_prefix) do
    local sprites = entities:get_sprite()
    all_lit = all_lit and sprites:get_animation() == "lit"
  end

  return all_lit
end




local function unlight_all_torches()

  for i=1,4 do
    map:get_entity("torch_" .. i):get_sprite():set_animation("unlit")
  end

  game:set_value("is_dark", true)
  enemy:set_visible(false)
end



function enemy:on_dying()

  map:set_entities_enabled("bat", false)
  hero:set_position(160, 181, 1)
  hero:set_direction(1)
  hero:freeze()
  game:set_value("is_dark", false)
  game:start_dialog("ganon.4")
  
end


