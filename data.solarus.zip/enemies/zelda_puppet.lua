local enemy = ...
local game = enemy:get_game()
local map = enemy:get_map()
local hero = map:get_entity("hero")
local damage


function enemy:on_created()

  enemy:set_life(1)
  enemy:set_damage(1)
  local sprite = enemy:create_sprite("npc/zelda")
  sprite:set_animation("stopped")
  enemy:set_attack_consequence("arrow", "custom")
  enemy:set_attack_consequence("boomerang", "immobilized")
  enemy:set_attack_consequence("sword", "protected")
  enemy:set_attack_consequence("thrown_item", "protected")
  enemy:set_attack_consequence("explosion", "protected")
  enemy:set_attack_consequence("fire", "protected")
  enemy:set_attack_consequence("hookshot", "protected")
  
  self:set_pushed_back_when_hurt(false)
  self:set_push_hero_on_sword(true)
  if game:get_value("difficulty") == "easy" then
    damage = 2
  else
    damage = 4
  end
end


function enemy:on_custom_attack_received(attack, sprite)

  if attack == "arrow" then
    local x, y, layer = hero:get_position()
    hero:start_hurt(x, y-2, damage)
  end
end
