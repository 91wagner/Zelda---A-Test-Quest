local enemy = ...
local map = enemy:get_map()
local game = map:get_game()

local creation_time_over = false
local timer_started = false

local function fairy_picked()

  sol.audio.play_sound("cursor")

  if game:get_value("fairy_possessed") or not game:has_item("empty_bottle") then
    game:add_life(24)
  else
    game:set_value("fairy_possessed", true)
    game:start_dialog("fairy_captured")
  end
end


function enemy:on_created()

  self:set_life(1)
  self:set_damage(0)
  self:create_sprite("enemies/fairy")
  self:set_hurt_style("monster")
  self:set_obstacle_behavior("flying")
  self:set_pushed_back_when_hurt(false)
  self:set_push_hero_on_sword(false)
  self:set_size(16, 16)
  self:set_origin(8, 8)
  self:set_invincible()
  self:set_attack_consequence("sword", "custom")
  self:set_layer_independent_collisions(true)
  local x, y = self:get_position()
  self:set_position(x, y, 2)
end

function enemy:on_restarted()
  self:go_random()
  if not timer_started then
    timer_started = true
    sol.timer.start(self, 1000, function()

      creation_time_over = true
    end)
  end
end


function enemy:on_movement_changed()

  local m = self:get_movement()
  local direction4 = m:get_direction4()
  local sprite = self:get_sprite()
  sprite:set_direction(direction4)
end


function enemy:go_random()
  local m = sol.movement.create("random_path")
  m:set_speed(32)
  m:start(self)
end


function enemy:on_custom_attack_received(attack, sprite)

  if attack == "sword" and creation_time_over then
    enemy:remove()
    fairy_picked()    
  end
end


function enemy:on_attacking_hero(hero, enemy_sprite)

  if creation_time_over then
    enemy:remove()
    fairy_picked()
  end
end