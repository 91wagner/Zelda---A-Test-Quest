local enemy = ...


-- wird vom "fireball_thrower" geworfen
function enemy:on_created()

  self:set_life(1)
  self:set_damage(2)
  self:create_sprite("enemies/fireball")
  self:set_size(16, 16)
  self:set_origin(8, 8)
  self:set_invincible()
  self:set_obstacle_behavior("flying")
  self:set_minimum_shield_needed(2)
end


function enemy:on_restarted()
  local hero_x, hero_y = self:get_map():get_entity("hero"):get_position()

  local angle = self:get_angle(hero_x, hero_y)
  
  self:go(angle)

end

function enemy:on_obstacle_reached()

  self:remove()
end


function enemy:go(angle)

  local m = sol.movement.create("straight")
  m:set_speed(160)
  m:set_angle(angle)
  m:set_smooth(false)
  m:start(self)
end
