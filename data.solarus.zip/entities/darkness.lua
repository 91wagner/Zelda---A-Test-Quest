local entity = ...

local map = entity:get_map()
local game = map:get_game()
local hero = map:get_entity("hero")



function entity:on_created()

  entity:set_traversable_by(true)
  entity:create_sprite("entities/dark")
  entity:set_origin(8,8)
end




function map:on_draw(dst_surface)

  if game:get_value("is_dark") then
    entity:get_sprite():set_direction(hero:get_direction())
    entity:set_position(hero:get_position())
    entity:set_visible(true)
  else
    entity:set_visible(false)
  end
  
end


function hero:on_position_changed(x,y,layer)
  
  if entity:is_visible() then
    entity:set_position(x,y,layer)
  end
end


function hero:on_movement_changed(movement)
  
  if entity:is_visible() then
    entity:get_sprite():set_direction(movement:get_direction4())
  end
end
